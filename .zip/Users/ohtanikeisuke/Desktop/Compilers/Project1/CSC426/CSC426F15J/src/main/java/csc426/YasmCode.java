package csc426;

public class YasmCode extends Code {
	public void print(String message) {
		for (char c : message.toCharArray()) {
			constant(c);
			writechar();
		}
	}

	public void load() {
		appendLine("LOAD");
	}

	public void store() {
		appendLine("STORE");
	}

	public void address(int level, int offset) {
		appendLine("ADDRESS " + level + ", " + offset + "");
	}

	public void halt() {
		appendLine("HALT");	
	}

	public void branch(String s) {
		appendLine("BRANCH " + s + "");
	}

	public void branchzero(String s) {
		appendLine("BRANCHZERO " + s + "");
	}

	public void branchneg(String s) {
		appendLine("BRANCHNEG " + s + "");
	}
	
	public void call(String s) {
		appendLine("CALL " + s + "");
	}

	public void ret() {
		appendLine("RETURN");
	}

	public void label(String s) {
		appendLine("LABEL " + s + "");
	}

	public void enter(int level) {
		appendLine("ENTER " + level + "");
	}

	public void exit(int level) {
		appendLine("EXIT " + level + "");
	}

	public void reserve(int n) {
		appendLine("RESERVE " + n + "");
	}

	public void drop(int n) {
		appendLine("DROP " + n + "");
	}

	public void readline() {
		appendLine("READLINE");
	}

	public void readint() {
		appendLine("READINT");
	}

	public void writeline() {
		appendLine("WRITELINE");
	}

	public void writeint() {
		appendLine("WRITEINT");
	}

	public void writechar() {
		appendLine("WRITECHAR");
	}
	
	public void constant(int n) {
		appendLine("CONSTANT " + n + "");
	}
	
	public void add() {
		appendLine("ADD");
	}
	
	public void sub() {
		appendLine("SUB");
	}
	
	public void mul() {
		appendLine("MUL");
	}
	
	public void div() {
		appendLine("DIV");
	}
	
	public void mod() {
		appendLine("MOD");
	}
	
	public void finish() {
		// Nothing to add
	}
}
