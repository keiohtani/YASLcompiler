package csc426.ast;

public class WhileStmt implements Stmt {
	private String test;
	private Stmt body;
	
	public WhileStmt(String test, Stmt body) {
		this.test = test;
		this.body = body;
	}

	public void accept(Visitor v) {
		v.whileDo(test, body);
	}
}
