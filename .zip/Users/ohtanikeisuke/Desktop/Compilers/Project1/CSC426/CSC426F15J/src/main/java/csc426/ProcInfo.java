package csc426;

import java.util.List;

import csc426.AST.Param;

public class ProcInfo implements Info {
	public ProcInfo(String label, List<Param> params) {
		this.label = label;
		this.params = params;
	}

	public String label;
	public List<Param> params;
}
