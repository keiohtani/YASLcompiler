package csc426

/**
 * @author bhoward
 */
class Lookahead(scanner: Scanner) {
  var current = scanner.next()
  
  def check(ttype: TokenType): Boolean = current.ttype == ttype
  
  def skip(): Token = {
    val token = current
    current = scanner.next()
    token
  }
  
  def matchType(ttype: TokenType): Token = {
    if (check(ttype)) {
      skip()
    } else {
      Console.err.println(s"Error: Expected a $ttype, found $current")
      sys.exit(1)
    }
  }
  
  def close(): Unit = scanner.close()
}