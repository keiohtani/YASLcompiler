package csc426;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import csc426.AST.Program;

public class Project3 {
	public static void main(String[] args) throws IOException {
		try {
			Lookahead lookahead = new Lookahead(new Scanner(new BufferedReader(new InputStreamReader(System.in))));
			Parser parser = new Parser(lookahead);

			Program program = parser.parseProgram();

			ASTVisitor<String> visitor = new ASTRenderVisitor();

			String result = program.accept(visitor);

			System.out.println(result);
		} catch (ParseError pe) {
			System.err.println(pe.getMessage());
			System.exit(1);
		}
	}
}
