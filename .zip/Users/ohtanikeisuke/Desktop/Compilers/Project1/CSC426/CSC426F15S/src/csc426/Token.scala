package csc426

/**
 * Enumeration of the different kinds of tokens in the YASL subset.
 *
 * @author bhoward
 */
trait TokenType {
  /**
   * @return true if this TokenType must be accompanied by a lexeme
   * to fully identify the Token (such as ID or NUM)
   */
  val withLexeme: Boolean = false
}
case object ID extends TokenType { // identifier, such as a variable name
  override val withLexeme: Boolean = true
}
case object NUM extends TokenType { // numeric literal
  override val withLexeme: Boolean = true
}
case object STRING extends TokenType { // string literal
  override val withLexeme: Boolean = true
}
case object PROGRAM extends TokenType // "program" keyword
case object CONST extends TokenType // "const" keyword
case object BEGIN extends TokenType // "begin" keyword
case object PRINT extends TokenType // "print" keyword
case object END extends TokenType // "end" keyword
case object DIV extends TokenType // "div" operator keyword
case object MOD extends TokenType // "mod" operator keyword
case object VAR extends TokenType // "var" keyword
case object INT extends TokenType // "int" type keyword
case object BOOL extends TokenType // "bool" type keyword
case object PROC extends TokenType // "proc" keyword
case object IF extends TokenType // "if" keyword
case object THEN extends TokenType // "then" keyword
case object ELSE extends TokenType // "else" keyword
case object WHILE extends TokenType // "while" keyword
case object DO extends TokenType // "do" keyword
case object PROMPT extends TokenType // "prompt" keyword
case object AND extends TokenType // "and" operator keyword
case object OR extends TokenType // "or" operator keyword
case object NOT extends TokenType // "not" operator keyword
case object TRUE extends TokenType // "true" constant keyword
case object FALSE extends TokenType // "false" constant keyword
case object SEMI extends TokenType // semicolon (;)
case object PERIOD extends TokenType // period (.)
case object COLON extends TokenType // colon (:)
case object LPAREN extends TokenType // left-parenthesis (()
case object RPAREN extends TokenType // right-parenthesis ())
case object COMMA extends TokenType // comma (,)
case object PLUS extends TokenType // plus operator (+)
case object MINUS extends TokenType // minus operator (-)
case object STAR extends TokenType // times operator (*)
case object ASSIGN extends TokenType // assignment operator (=)
case object EQUAL extends TokenType // equality operator (==)
case object NOTEQUAL extends TokenType // inequality operator (<>)
case object LESSEQUAL extends TokenType // less-or-equal operator (<=)
case object GREATEREQUAL extends TokenType // greater-or-equal operator (>=)
case object LESS extends TokenType // less-than operator (<)
case object GREATER extends TokenType // greater-than operator (>)
case object EOF extends TokenType // end-of-file

/**
 * A Token represents one lexical unit of a YASL source program. A Token object
 * stores a position (line and column numbers, each starting from 1), a
 * TokenType, and a lexeme (string value -- for the fixed tokens, this is
 * redundant, but for identifiers and numbers it specifies which particular one
 * it is).
 *
 * @author bhoward
 */
case class Token(line: Int, column: Int, ttype: TokenType, lexeme: String) {
  override def toString(): String = {
    if (ttype.withLexeme) {
      s"$ttype $lexeme $line:$column"
    } else {
      s"$ttype $line:$column"
    }
  }
}