package csc426;

import static org.junit.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

import org.junit.Test;

import csc426.parser.ErrorLog;
import csc426.parser.Lexer;
import csc426.parser.Position;
import csc426.parser.Token;
import csc426.parser.TokenType;

public class ScannerTest4 {

	/**
	 * A test of error messages.
	 * 
	 * test9.in is
-------
// Errors
/ Illegal comment
{bad characters: !@#$%^&}!@#$%^&
[]{}|\\//The { and } are OK
`~_'?{a closed comment


foo


}
{and an unclosed one


bar
-------
	 * @throws IOException 
	 */
	@Test
	public void test9() throws IOException {
		Reader in = new BufferedReader(new FileReader("resource/project1/test9.in"));
		ErrorLog log = new ErrorLog();
		Lexer scanner = new Lexer(in, log);

		Token t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(2, 3), t.position);
		assertEquals("Illegal", t.lexeme);
		
		String expected1 = "Error: Malformed comment at 2:1\n";
		assertEquals(expected1, log.toString());
		log.reset();
		
		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(2, 11), t.position);
		assertEquals("comment", t.lexeme);
		
		String expected2 = "";
		assertEquals(expected2, log.toString());
		log.reset();
		
		t = scanner.next();
		assertEquals(TokenType.EOF, t.type);
		assertEquals(new Position(16, 1), t.position);
		
		String expected3 =
				"Error: Unexpected character (!) at 3:26\n"
				+ "Error: Unexpected character (@) at 3:27\n"
				+ "Error: Unexpected character (#) at 3:28\n"
				+ "Error: Unexpected character ($) at 3:29\n"
				+ "Error: Unexpected character (%) at 3:30\n"
				+ "Error: Unexpected character (^) at 3:31\n"
				+ "Error: Unexpected character (&) at 3:32\n"
				+ "Error: Unexpected character ([) at 4:1\n"
				+ "Error: Unexpected character (]) at 4:2\n"
				+ "Error: Unexpected character (|) at 4:5\n"
				+ "Error: Unexpected character (\\) at 4:6\n"
				+ "Error: Unexpected character (\\) at 4:7\n"
				+ "Error: Unexpected character (`) at 5:1\n"
				+ "Error: Unexpected character (~) at 5:2\n"
				+ "Error: Unexpected character (_) at 5:3\n"
				+ "Error: Unexpected character (') at 5:4\n"
				+ "Error: Unexpected character (?) at 5:5\n"
				+ "Error: Unclosed comment at 12:1\n";
		assertEquals(expected3, log.toString());
		log.reset();
	}
}
