package csc426;

public interface Token {
	TokenType getType();
	
	String lexeme();
}
