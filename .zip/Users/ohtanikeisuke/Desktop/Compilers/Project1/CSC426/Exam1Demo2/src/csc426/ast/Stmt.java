package csc426.ast;

public interface Stmt {
	public void accept(Visitor v);
}
