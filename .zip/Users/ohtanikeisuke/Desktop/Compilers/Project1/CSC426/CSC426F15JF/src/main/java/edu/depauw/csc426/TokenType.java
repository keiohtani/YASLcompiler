package edu.depauw.csc426;

/**
 * Enumeration of the different kinds of tokens in the YASL subset.
 * 
 * @author bhoward
 */
public enum TokenType {
	ID, // identifier, such as a variable name
	NUM, // numeric literal
	PROGRAM, // "program" keyword
	CONST, // "const" keyword
	BEGIN, // "begin" keyword
	PRINT, // "print" keyword
	END, // "end" keyword
	DIV, // "div" operator keyword
	MOD, // "mod" operator keyword
	SEMI, // semicolon (;)
	PERIOD, // period (.)
	PLUS, // plus operator (+)
	MINUS, // minus operator (-)
	STAR, // times operator (*)
	ASSIGN, // assignment operator (=)
	EOF // end-of-file
}
