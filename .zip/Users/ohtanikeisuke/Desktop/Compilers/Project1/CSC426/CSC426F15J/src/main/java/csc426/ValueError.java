package csc426;

@SuppressWarnings("serial")
public class ValueError extends Exception {
	public ValueError(String message) {
		super(message);
	}
}
