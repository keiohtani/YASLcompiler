package csc426;

public class CharToken implements Token {
	private char c;
	private TokenType type;

	public CharToken(char c) {
		this.c = c;
		if (c == '=') {
			this.type = TokenType.ASSIGN;
		} else {
			this.type = TokenType.OP;
		}
	}

	public TokenType getType() {
		return type;
	}

	@Override
	public String toString() {
		String result = type.toString();
		if (type == TokenType.OP) {
			result += " " + c;
		}
		return result;
	}

	@Override
	public String lexeme() {
		return Character.toString(c);
	}
}
