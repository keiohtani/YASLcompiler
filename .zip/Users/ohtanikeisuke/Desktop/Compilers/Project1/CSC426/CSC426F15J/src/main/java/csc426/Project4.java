package csc426;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.io.Reader;

import csc426.AST.Program;

public class Project4 {
	public static void main(String[] args) throws IOException {
		java.util.Scanner input = new java.util.Scanner(System.in);
		PrintStream output = System.out;

		File file = null;
		if (args.length < 1) {
			output.print("Source file: ");
			file = new File(input.nextLine());
		} else {
			file = new File(args[0]);
		}

		Reader in = null;
		try {
			in = new BufferedReader(new FileReader(file));
			Lookahead lookahead = new Lookahead(new Scanner(in));
			
			Parser parser = new Parser(lookahead);
			Program program = parser.parseProgram();
			
			ASTVisitor<Value> visitor = new InterpreterVisitor(input, output);
			program.accept(visitor);
		} catch (ParseError pe) {
			System.err.println(pe.getMessage());
			System.exit(1);
		} catch (InterpreterError ie) {
			System.err.println(ie.getMessage());
			System.exit(1);
		} finally {
			if (in != null) {
				in.close();
			}
			input.close();
		}
	}
}
