package csc426;

import static org.junit.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.io.Reader;

import org.junit.Test;

public class ScannerTest4 {

	/**
	 * A test of error messages. Uses System.setErr to redirect
	 * the standard error output to a ByteArrayOutputStream,
	 * which can then be examined.
	 * 
	 * test9.in is
-------
// Errors
/ Illegal comment
{bad characters: !@#$%^&}!@#$%^&
[]{}|\\//The { and } are OK
`~_'?{a closed comment


foo


}
{and an unclosed one


bar
-------
	 * @throws IOException 
	 */
	@Test
	public void test9() throws IOException {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		PrintStream err = new PrintStream(out);
		System.setErr(err);
		
		Reader in = new BufferedReader(new FileReader("resource/project1/test9.in"));
		Scanner scanner = new Scanner(in);

		Token t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(2, 3), t.position);
		assertEquals("Illegal", t.lexeme);
		
		String expected1 = "Error: Malformed comment at 2:1\n";
		assertEquals(expected1, out.toString());
		out.reset();
		
		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(2, 11), t.position);
		assertEquals("comment", t.lexeme);
		
		String expected2 = "";
		assertEquals(expected2, out.toString());
		out.reset();
		
		t = scanner.next();
		assertEquals(TokenType.EOF, t.type);
		assertEquals(new Position(16, 1), t.position);
		
		String expected3 =
				"Error: Unexpected character (!) at 3:26\n"
				+ "Error: Unexpected character (@) at 3:27\n"
				+ "Error: Unexpected character (#) at 3:28\n"
				+ "Error: Unexpected character ($) at 3:29\n"
				+ "Error: Unexpected character (%) at 3:30\n"
				+ "Error: Unexpected character (^) at 3:31\n"
				+ "Error: Unexpected character (&) at 3:32\n"
				+ "Error: Unexpected character ([) at 4:1\n"
				+ "Error: Unexpected character (]) at 4:2\n"
				+ "Error: Unexpected character (|) at 4:5\n"
				+ "Error: Unexpected character (\\) at 4:6\n"
				+ "Error: Unexpected character (\\) at 4:7\n"
				+ "Error: Unexpected character (`) at 5:1\n"
				+ "Error: Unexpected character (~) at 5:2\n"
				+ "Error: Unexpected character (_) at 5:3\n"
				+ "Error: Unexpected character (') at 5:4\n"
				+ "Error: Unexpected character (?) at 5:5\n"
				+ "Error: Unclosed comment at 12:1\n";
		assertEquals(expected3, out.toString());
		out.reset();
	}
}
