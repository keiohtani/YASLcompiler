package csc426.parser;

@SuppressWarnings("serial")
public class ParserException extends Exception {
	public ParserException(String message) {
		super(message);
	}
}
