package csc426.parser;

public enum TokenType {
	ID, ASSIGN, NUM, OP, BEGIN, END, WHILE, IF, DO, UNTIL, PRINT, INPUT, SUB, CALL, EOF;
	
	public static TokenType[] keywords = { BEGIN, END, WHILE, IF, DO, UNTIL, PRINT, INPUT, SUB, CALL };
}
