package csc426.ast;

import csc426.SymbolTable;
import csc426.Value;

public interface Stmt {
	/**
	 * Produce a string representation of this AST node at the given indent
	 * level.
	 * 
	 * @param indent
	 *            the initial number of spaces at the beginning of each line
	 * @return the string representing this tree
	 */
	String render(String indent);

	/**
	 * Interpret this statement in the context of the given symbol table.
	 * 
	 * @param table
	 * @throws Exception 
	 */
	void interpret(SymbolTable<Value> table) throws Exception;
}
