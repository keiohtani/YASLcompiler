package csc426.ast;

public class AssignOpStmt implements Stmt {
	private String lhs;
	private String id1;
	private String op;
	private String id2;

	public AssignOpStmt(String lhs, String id1, String op, String id2) {
		this.lhs = lhs;
		this.id1 = id1;
		this.op = op;
		this.id2 = id2;
	}

	public void accept(Visitor v) {
		v.assignOp(lhs, id1, op, id2);
	}
}
