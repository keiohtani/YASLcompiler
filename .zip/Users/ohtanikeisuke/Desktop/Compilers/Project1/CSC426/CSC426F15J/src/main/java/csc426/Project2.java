package csc426;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

public class Project2 {
	public static void main(String[] args) throws IOException {
		try {
			Lookahead lookahead = new Lookahead(new Scanner(new BufferedReader(new InputStreamReader(System.in))));

			Map<String, String> constant = new HashMap<String, String>();

			lookahead.match(TokenType.PROGRAM);
			lookahead.match(TokenType.ID);
			lookahead.match(TokenType.SEMI);

			// Process the const declarations
			while (lookahead.check(TokenType.CONST)) {
				lookahead.skip();
				Token id = lookahead.match(TokenType.ID);
				lookahead.match(TokenType.ASSIGN);
				Token num = lookahead.match(TokenType.NUM);
				lookahead.match(TokenType.SEMI);

				constant.put(id.lexeme, num.lexeme);
			}

			lookahead.match(TokenType.BEGIN);

			// Process the print statements
			while (lookahead.check(TokenType.PRINT)) {
				lookahead.skip();
				Stack<TokenType> stack = new Stack<TokenType>();
				stack.push(TokenType.PRINT);

				while (!lookahead.check(TokenType.SEMI)) {
					if (lookahead.check(TokenType.NUM)) {
						Token num = lookahead.skip();
						System.out.println(num.lexeme);
					} else if (lookahead.check(TokenType.ID)) {
						Token id = lookahead.skip();
						if (constant.containsKey(id.lexeme)) {
							System.out.println(constant.get(id.lexeme));
						} else {
							System.err.println("Error: Unknown identifier " + id.lexeme);
							System.exit(1);
						}
					} else {
						Token op = lookahead.skip();
						int precedence = precedence(op.type);
						while (!stack.isEmpty() && precedence <= precedence(stack.peek())) {
							System.out.println(operator(stack.pop()));
						}
						stack.push(op.type);
					}
				}

				lookahead.skip();
				while (!stack.isEmpty()) {
					System.out.println(operator(stack.pop()));
				}
			}

			lookahead.match(TokenType.END);
			lookahead.match(TokenType.PERIOD);
			lookahead.match(TokenType.EOF);
		} catch (ParseError pe) {
			System.err.println(pe.getMessage());
			System.exit(1);
		}
	}

	private static String operator(TokenType type) throws ParseError {
		switch (type) {
		case PRINT:
			return "PRINT";
		case PLUS:
			return "+";
		case MINUS:
			return "-";
		case STAR:
			return "*";
		case DIV:
			return "DIV";
		case MOD:
			return "MOD";
		default:
			throw new ParseError("Error: Expected an operator; found " + type);
		}
	}

	private static int precedence(TokenType type) throws ParseError {
		switch (type) {
		case PRINT:
			return 0;
		case PLUS:
		case MINUS:
			return 1;
		case STAR:
		case DIV:
		case MOD:
			return 2;
		default:
			throw new ParseError("Error: Expected an operator; found " + type);
		}
	}
}
