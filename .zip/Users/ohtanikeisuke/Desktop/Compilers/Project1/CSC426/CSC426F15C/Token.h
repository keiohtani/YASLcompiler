/*
 * Token.h
 *
 *  Created on: Aug 30, 2015
 *      Author: bhoward
 */

#ifndef TOKEN_H_
#define TOKEN_H_

#include <string>
#include <iosfwd>

enum Token_Type {
	ID,
	NUM,
	PROGRAM,
	CONST,
	BEGIN,
	PRINT,
	END,
	DIV,
	MOD,
	SEMI,
	PERIOD,
	PLUS,
	MINUS,
	STAR,
	ASSIGN,
	EOFILE // EOF is already used in cstdio
};

// Format a Token_Type for display on an output stream
std::ostream& operator<<(std::ostream& out, Token_Type type);

struct Token {
	int line, column;
	Token_Type type;
	std::string lexeme;
};

// Format a Token for display on an output stream
std::ostream& operator<<(std::ostream& out, const Token& token);

#endif /* TOKEN_H_ */
