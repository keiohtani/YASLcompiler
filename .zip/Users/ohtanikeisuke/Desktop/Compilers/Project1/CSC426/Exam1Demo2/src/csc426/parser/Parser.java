package csc426.parser;

import java.util.ArrayList;
import java.util.List;

import csc426.ast.AssignIdStmt;
import csc426.ast.AssignNumStmt;
import csc426.ast.AssignOpStmt;
import csc426.ast.CallStmt;
import csc426.ast.IfStmt;
import csc426.ast.InputStmt;
import csc426.ast.PrintStmt;
import csc426.ast.SeqStmt;
import csc426.ast.Stmt;
import csc426.ast.SubStmt;
import csc426.ast.UntilStmt;
import csc426.ast.WhileStmt;

public class Parser {
	private Lexer scanner;

	public Parser(Lexer scanner) {
		this.scanner = scanner;
	}

	/**
	 * Parse an entire program (a statement followed by EOF).
	 * 
	 * @return the Stmt AST object
	 * @throws ParserException
	 */
	public Stmt parseProgram() throws ParserException {
		Stmt stmt = parseS();
		scanner.match(TokenType.EOF);
		return stmt;
	}
	
	/**
	 * Parse one statement from the scanner.
	 * 
	 * @return the Stmt AST object
	 * @throws ParserException 
	 */
	public Stmt parseS() throws ParserException {
		if (scanner.check(TokenType.ID)) {
			String lhs = scanner.match(TokenType.ID).lexeme();
			scanner.match(TokenType.ASSIGN);
			return parseU(lhs);
		} else if (scanner.check(TokenType.BEGIN)) {
			scanner.match(TokenType.BEGIN);
			List<Stmt> stmts = parseT(new ArrayList<Stmt>());
			scanner.match(TokenType.END);
			return new SeqStmt(stmts);
		} else if (scanner.check(TokenType.WHILE)) {
			scanner.match(TokenType.WHILE);
			String test = scanner.match(TokenType.ID).lexeme();
			Stmt body = parseS();
			return new WhileStmt(test, body);
		} else if (scanner.check(TokenType.IF)) {
			scanner.match(TokenType.IF);
			String test = scanner.match(TokenType.ID).lexeme();
			Stmt body = parseS();
			return new IfStmt(test, body);
		} else if (scanner.check(TokenType.DO)) {
			scanner.match(TokenType.DO);
			Stmt body = parseS();
			scanner.match(TokenType.UNTIL);
			String test = scanner.match(TokenType.ID).lexeme();
			return new UntilStmt(test, body);
		} else if (scanner.check(TokenType.PRINT)) {
			scanner.match(TokenType.PRINT);
			String id = scanner.match(TokenType.ID).lexeme();
			return new PrintStmt(id);
		} else if (scanner.check(TokenType.INPUT)) {
			scanner.match(TokenType.INPUT);
			String id = scanner.match(TokenType.ID).lexeme();
			return new InputStmt(id);
		} else if (scanner.check(TokenType.SUB)) {
			scanner.match(TokenType.SUB);
			String id = scanner.match(TokenType.ID).lexeme();
			Stmt body = parseS();
			return new SubStmt(id, body);
		} else if (scanner.check(TokenType.CALL)) {
			scanner.match(TokenType.CALL);
			String id = scanner.match(TokenType.ID).lexeme();
			return new CallStmt(id);
		} else {
			throw new ParserException("Unrecognized statement");
		}
	}

	/**
	 * Parse the rest of a list of statements from the scanner.
	 * 
	 * @param stmts
	 *            the list of previous statements in this list
	 * @return the complete list of statements
	 * @throws ParserException 
	 */
	public List<Stmt> parseT(List<Stmt> stmts) throws ParserException {
		if (scanner.check(TokenType.END)) {
			return stmts;
		} else {
			stmts.add(parseS());
			return parseT(stmts);
		}
	}

	/**
	 * Parse the right-hand side of an assignment statement.
	 * 
	 * @param lhs
	 *            the identifier from the left-hand side
	 * @return the Stmt AST object for this assignment
	 * @throws ParserException 
	 */
	public Stmt parseU(String lhs) throws ParserException {
		if (scanner.check(TokenType.NUM)) {
			String num = scanner.match(TokenType.NUM).lexeme();
			return new AssignNumStmt(lhs, Double.parseDouble(num));
		} else {
			String id = scanner.match(TokenType.ID).lexeme();
			return parseV(lhs, id);
		}
	}

	/**
	 * Parse the rest of the right-hand side of an assignment.
	 * 
	 * @param lhs
	 *            the identifier from the left-hand side
	 * @param id
	 *            the identifier from the start of the right-hand side
	 * @return the Stmt AST object for this assignment
	 * @throws ParserException 
	 */
	public Stmt parseV(String lhs, String id) throws ParserException {
		if (scanner.check(TokenType.OP)) {
			String op = scanner.match(TokenType.OP).lexeme();
			String id2 = scanner.match(TokenType.ID).lexeme();
			return new AssignOpStmt(lhs, id, op, id2);
		} else {
			return new AssignIdStmt(lhs, id);
		}
	}
}
