package csc426;

public interface Info {
}
