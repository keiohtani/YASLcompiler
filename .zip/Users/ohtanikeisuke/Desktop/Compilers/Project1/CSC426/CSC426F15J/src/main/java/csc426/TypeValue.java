package csc426;

import java.util.Iterator;
import java.util.List;

import csc426.AST.Param;
import csc426.AST.Param.Var;
import csc426.AST.Type;

public abstract class TypeValue {
	public Type type() throws ValueError {
		throw new ValueError("Not a value type");
	}

	public boolean isVar() throws ValueError {
		throw new ValueError("Not a value type");
	}

	public void match(List<TypeValue> args) throws ValueError {
		throw new ValueError("Value is not a procedure");
	}

	public static class IntVal extends TypeValue {
		@Override
		public Type type() {
			return Type.Int;
		}

		@Override
		public boolean isVar() {
			return false;
		}
	}

	public static class IntVar extends TypeValue {
		@Override
		public Type type() {
			return Type.Int;
		}

		@Override
		public boolean isVar() {
			return true;
		}
	}

	public static class BoolVal extends TypeValue {
		@Override
		public Type type() {
			return Type.Bool;
		}

		@Override
		public boolean isVar() {
			return false;
		}
	}

	public static class BoolVar extends TypeValue {
		@Override
		public Type type() {
			return Type.Bool;
		}

		@Override
		public boolean isVar() {
			return true;
		}
	}

	public static class ProcVal extends TypeValue {
		private List<Param> params;

		public ProcVal(List<Param> params) {
			this.params = params;
		}

		@Override
		public void match(List<TypeValue> args) throws ValueError {
			if (args.size() != params.size()) {
				throw new ValueError("Wrong number of arguments");
			}

			Iterator<TypeValue> it = args.iterator();
			for (Param param : params) {
				TypeValue arg = it.next();
				if (param.type != arg.type()) {
					throw new ValueError("Type mismatch in " + param);
				}
				if (param instanceof Var && !arg.isVar()) {
					throw new ValueError("Variable parameter required in " + param);
				}
			}
		}
	}
}
