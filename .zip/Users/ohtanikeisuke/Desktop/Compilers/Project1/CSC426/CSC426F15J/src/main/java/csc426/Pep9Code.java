package csc426;

public class Pep9Code extends Code {
	void print(String message) {
		String msgLabel = newLabel();
		String skipLabel = newLabel();
		appendLine("BR " + skipLabel);
		appendLine(msgLabel + ": .ASCII \"" + escape(message) + "\"");
		appendLine(".BYTE 0");
		appendLine(skipLabel + ": STRO " + msgLabel + ", d");
	}

	private String escape(String message) {
		StringBuilder b = new StringBuilder();
		for (char c : message.toCharArray()) {
			switch (c) {
			case '\'':
				b.append("\\'");
				break;
			case '\"':
				b.append("\\\"");
				break;
			case '\\':
				b.append("\\\\");
				break;
			case '\b':
				b.append("\\b");
				break;
			case '\f':
				b.append("\\f");
				break;
			case '\n':
				b.append("\\n");
				break;
			case '\r':
				b.append("\\r");
				break;
			case '\t':
				b.append("\\t");
				break;
			case '\u000b':
				b.append("\\v");
				break;
			default:
				b.append(c);
				break;
			}
		}
		return b.toString();
	}

	void load() {
		appendLine("LDWA 0, sf");
		appendLine("STWA 0, s");
	}

	void store() {
		appendLine("LDWA 2, s");
		appendLine("STWA 0, sf");
		appendLine("ADDSP 4, i");
	}

	void address(int level, int offset) {
		appendLine("LDWX " + (2 * level) + ", i");
		appendLine("LDWA display_, x");
		appendLine("ADDA " + (2 * offset) + ", i");
		appendLine("SUBSP 2, i");
		appendLine("STWA 0, s");
	}

	void halt() {
		appendLine("STOP");
	}

	void branch(String s) {
		appendLine("BR " + s);
	}

	void branchzero(String s) {
		appendLine("ADDSP 2, i");
		appendLine("LDWA -2, s");
		appendLine("BREQ " + s);
	}

	void branchneg(String s) {
		appendLine("ADDSP 2, i");
		appendLine("LDWA -2, s");
		appendLine("BRLT " + s);
	}

	void call(String s) {
		appendLine("CALL " + s);
	}

	void ret() {
		appendLine("RET");
	}

	void label(String s) {
		appendLine(s + ": NOP0");
	}

	void enter(int level) {
		appendLine("LDWX " + (2 * level) + ", i");
		appendLine("LDWA display_, x");
		appendLine("SUBSP 2, i");
		appendLine("STWA 0, s");
		appendLine("MOVSPA");
		appendLine("STWA display_, x");
	}

	void exit(int level) {
		appendLine("LDWA 0, s");
		appendLine("ADDSP 2, i");
		appendLine("LDWX " + (2 * level) + ", i");
		appendLine("STWA display_, x");
	}

	void reserve(int n) {
		appendLine("SUBSP " + (2 * n) + ", i");
	}

	void drop(int n) {
		appendLine("ADDSP " + (2 * n) + ", i");
	}

	void readline() {
		appendLine("LDBA charIn, d");
		appendLine("STBA -1, s");
	}

	void readint() {
		appendLine("SUBSP 2, i");
		appendLine("DECI 0, s");
	}

	void writeline() {
		appendLine("LDBA 10, i");
		appendLine("STBA charOut, d");
	}

	void writeint() {
		appendLine("DECO 0, s");
		appendLine("ADDSP 2, i");
	}

	void writechar() {
		appendLine("LDBA 1, s");
		appendLine("STBA charOut, d");
		appendLine("ADDSP 2, i");
	}

	void constant(int n) {
		appendLine("LDWA " + n + ", i");
		appendLine("SUBSP 2, i");
		appendLine("STWA 0, s");
	}

	void add() {
		appendLine("LDWA 2, s");
		appendLine("ADDA 0, s");
		appendLine("ADDSP 2, i");
		appendLine("STWA 0, s");
	}

	void sub() {
		appendLine("LDWA 2, s");
		appendLine("SUBA 0, s");
		appendLine("ADDSP 2, i");
		appendLine("STWA 0, s");
	}

	void mul() {
		appendLine("CALL mult_");
		appendLine("ADDSP 2, i");
	}

	void div() {
		appendLine("CALL div_");
		appendLine("ADDSP 2, i");
	}

	void mod() {
		appendLine("CALL div_");
		appendLine("LDWA 0, s");
		appendLine("STWA 2, s");
		appendLine("ADDSP 2, i");
	}

	void finish() {
		// Append the runtime library
		appendLine("display_: .BLOCK  20");
		appendLine("mult_:    LDWX    16,i");
		appendLine("          LDWA    0,i");
		appendLine("          STWA    -2,s");
		appendLine("M_0:      LDWA    -2,s");
		appendLine("          ASRA");
		appendLine("          STWA    -2,s");
		appendLine("          LDWA    2,s");
		appendLine("          RORA");
		appendLine("          STWA    2,s");
		appendLine("          BRC     M_2");
		appendLine("M_1:      SUBX    1,i");
		appendLine("          BRNE    M_0");
		appendLine("          BR      M_4");
		appendLine("M_2:      LDWA    -2,s");
		appendLine("          SUBA    4,s");
		appendLine("          STWA    -2,s");
		appendLine("M_3:      SUBX    1,i");
		appendLine("          BREQ    M_4");
		appendLine("          LDWA    -2,s");
		appendLine("          ASRA");
		appendLine("          STWA    -2,s");
		appendLine("          LDWA    2,s");
		appendLine("          RORA");
		appendLine("          STWA    2,s");
		appendLine("          BRC     M_3");
		appendLine("          LDWA    -2,s");
		appendLine("          ADDA    4,s");
		appendLine("          STWA    -2,s");
		appendLine("          BR      M_1");
		appendLine("M_4:      LDWA    -2,s");
		appendLine("          ASRA");
		appendLine("          LDWX    2,s");
		appendLine("          RORX");
		appendLine("          STWX    4,s");
		appendLine("          STWA    2,s");
		appendLine("          RET");
		appendLine("div_:     LDWX    0,i");
		appendLine("          LDWA    4,s");
		appendLine("          BRGE    M_5");
		appendLine("          NEGA");
		appendLine("          STWA    4,s");
		appendLine("          ORX     3,i");
		appendLine("M_5:      LDWA    2,s");
		appendLine("          BRGE    M_6");
		appendLine("          NEGA");
		appendLine("          STWA    2,s");
		appendLine("          ADDX    2,i");
		appendLine("M_6:      STBX    -3,s");
		appendLine("          LDWA    0,i");
		appendLine("          STWA    -2,s");
		appendLine("          LDWX    16,i");
		appendLine("M_7:      LDWA    4,s");
		appendLine("          ASLA");
		appendLine("          STWA    4,s");
		appendLine("          LDWA    -2,s");
		appendLine("          ROLA");
		appendLine("          BRC     M_8");
		appendLine("          SUBA    2,s");
		appendLine("          BR      M_9");
		appendLine("M_8:      ADDA    2,s");
		appendLine("M_9:      STWA    -2,s");
		appendLine("          BRLT    M_10");
		appendLine("          LDWA    4,s");
		appendLine("          ORA     1,i");
		appendLine("          STWA    4,s");
		appendLine("M_10:     SUBX    1,i");
		appendLine("          BRNE    M_7");
		appendLine("          LDWA    -2,s");
		appendLine("          BRGE    M_11");
		appendLine("          ADDA    2,s");
		appendLine("M_11:     LDBX    -3,s");
		appendLine("          ANDX    1,i");
		appendLine("          BREQ    M_12");
		appendLine("          NEGA");
		appendLine("M_12:     STWA    2,s");
		appendLine("          LDBX    -3,s");
		appendLine("          ANDX    2,i");
		appendLine("          BREQ    M_13");
		appendLine("          LDWA    4,s");
		appendLine("          NEGA");
		appendLine("          STWA    4,s");
		appendLine("M_13:     RET");
		appendLine("          .END");
	}
}
