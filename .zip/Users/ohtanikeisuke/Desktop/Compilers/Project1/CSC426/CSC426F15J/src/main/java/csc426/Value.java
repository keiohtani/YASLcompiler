package csc426;

import java.util.Iterator;
import java.util.List;

import csc426.AST.Block;
import csc426.AST.Param;
import csc426.AST.Param.Var;

public abstract class Value {
	public boolean boolValue() throws ValueError {
		throw new ValueError("Value is not a boolean");
	}

	public int intValue() throws ValueError {
		throw new ValueError("Value is not an integer");
	}

	public void set(Value value) throws ValueError {
		throw new ValueError("Value is not a variable");
	}

	public void call(List<Value> args, InterpreterVisitor visitor, SymbolTable<Value> table) throws ValueError {
		throw new ValueError("Value is not a procedure");
	}

	public static class IntValue extends Value {
		private int value;

		public IntValue(int value) {
			this.value = value;
		}

		@Override
		public int intValue() {
			return value;
		}
	}

	public static class BoolValue extends Value {
		private boolean value;

		public BoolValue(boolean value) {
			this.value = value;
		}

		@Override
		public boolean boolValue() {
			return value;
		}
	}

	public static class IntCell extends Value {
		private IntValue value;

		public IntCell() {
			this.value = null;
		}

		@Override
		public int intValue() throws ValueError {
			if (value != null) {
				return value.intValue();
			} else {
				throw new ValueError("Uninitialized variable");
			}
		}

		@Override
		public void set(Value value) throws ValueError {
			this.value = new IntValue(value.intValue());
		}
	}

	public static class BoolCell extends Value {
		private BoolValue value;

		public BoolCell() {
			this.value = null;
		}

		@Override
		public boolean boolValue() throws ValueError {
			if (value != null) {
				return value.boolValue();
			} else {
				throw new ValueError("Uninitialized variable");
			}
		}

		@Override
		public void set(Value value) throws ValueError {
			this.value = new BoolValue(value.boolValue());
		}
	}

	public static class ProcValue extends Value {
		private List<Param> params;
		private Block block;

		public ProcValue(List<Param> params, Block block) {
			this.params = params;
			this.block = block;
		}

		@Override
		public void call(List<Value> args, InterpreterVisitor visitor, SymbolTable<Value> table) throws ValueError {
			if (args.size() != params.size()) {
				throw new ValueError("Wrong number of arguments");
			}

			try {
				Iterator<Value> it = args.iterator();
				for (Param param : params) {
					Value arg = it.next();
					if (param instanceof Var) {
						table.add(param.id, arg);
					} else {
						switch (param.type) {
						case Int: {
							Value value = new IntCell();
							value.set(new IntValue(arg.intValue()));
							table.add(param.id, value);
							break;
						}
						case Bool: {
							Value value = new BoolCell();
							value.set(new BoolValue(arg.boolValue()));
							table.add(param.id, value);
							break;
						}
						}
					}
				}
			} catch (TableError e) {
				throw new ValueError(e.getMessage());
			}

			block.accept(visitor);
		}
	}
}
