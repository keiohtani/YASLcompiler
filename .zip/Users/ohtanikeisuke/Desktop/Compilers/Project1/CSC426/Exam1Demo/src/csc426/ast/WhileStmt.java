package csc426.ast;

import csc426.SymbolTable;
import csc426.Value;

public class WhileStmt implements Stmt {
	private String test;
	private Stmt body;
	
	public WhileStmt(String test, Stmt body) {
		this.test = test;
		this.body = body;
	}

	public String render(String indent) {
		String result = indent + "WHILE " + test + "\n";
		result += body.render(indent + "  ");
		return result;
	}

	public void interpret(SymbolTable<Value> table) throws Exception {
		Value value = table.lookup(test);
		if (value == null) {
			throw new Exception("Unknown variable " + test);
		}
		
		double num = value.asDouble();
		while (num != 0.0) {
			body.interpret(table);
			value = table.lookup(test); // shouldn't be null
			num = value.asDouble();
		}
	}
}
