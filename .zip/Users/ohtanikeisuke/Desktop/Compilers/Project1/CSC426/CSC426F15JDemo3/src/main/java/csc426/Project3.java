package csc426;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import csc426.ast.Program;
import csc426.parser.ErrorLog;
import csc426.parser.Lexer;
import csc426.parser.Lookahead;
import csc426.parser.Parser;

public class Project3 {
	public static void main(String[] args) {
		JFileChooser chooser = new JFileChooser();
		JFrame frame = new JFrame("Output");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(800, 600);
		JTextArea output = new JTextArea();
		frame.add(new JScrollPane(output));
		frame.setVisible(true);

		ErrorLog log = new ErrorLog();

		File file = null;
		if (args.length < 1) {
			if (chooser.showOpenDialog(frame) != JFileChooser.APPROVE_OPTION) {
				System.exit(1);
			}
			file = chooser.getSelectedFile();
		} else {
			file = new File(args[0]);
		}

		try (Reader in = new BufferedReader(new FileReader(file));
				Lexer lexer = new Lexer(in, log);
				Lookahead lookahead = new Lookahead(lexer, log)) {
			Parser parser = new Parser(lookahead);

			Program program = parser.parseProgram();

			String result = program.render("");

			output.setText(result);
		} catch (IOException e) {
			log.add(e.getMessage());
		}

		if (log.nonEmpty()) {
			System.err.print(log);
		}
	}
}
