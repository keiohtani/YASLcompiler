package csc426.ast;

public class InputStmt implements Stmt {
	private String id;
	
	public InputStmt(String id) {
		this.id = id;
	}

	public void accept(Visitor v) {
		v.input(id);
	}
}
