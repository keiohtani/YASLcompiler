package csc426.interpret;

import java.io.PrintStream;
import java.util.List;
import java.util.Scanner;

import csc426.ast.Stmt;
import csc426.ast.Visitor;
import csc426.util.SymbolTable;

public class Interpreter implements Visitor {
	private Scanner consoleInput;
	private PrintStream consoleOutput;
	private SymbolTable<Value> table;

	public Interpreter(Scanner consoleInput, PrintStream consoleOutput) {
		this.consoleInput = consoleInput;
		this.consoleOutput = consoleOutput;
		this.table = new SymbolTable<>();
	}
	
	public void run(Stmt program) {
		table.enter();
		program.accept(this);
		table.exit();
	}

	public void assignId(String lhs, String id) {
		double num = lookupVariable(id);
		table.bind(lhs, new NumValue(num));
	}

	public void assignNum(String lhs, double num) {
		table.bind(lhs, new NumValue(num));
	}

	public void assignOp(String lhs, String id1, String op, String id2) {
		double num1 = lookupVariable(id1);
		double num2 = lookupVariable(id2);

		double result = 0;
		switch (op) {
		case "+":
			result = num1 + num2;
			break;

		case "-":
			result = num1 - num2;
			break;

		case "*":
			result = num1 * num2;
			break;

		case "/":
			result = num1 / num2;
			break;

		case "^":
			result = Math.pow(num1, num2);
			break;

		default:
			throw new InterpreterException("Unknown operator " + op);
		}
		table.bind(lhs, new NumValue(result));
	}

	public void call(String id) {
		Stmt stmt = lookupStatement(id);
		table.enter();
		stmt.accept(this);
		table.exit();
	}

	public void ifThen(String test, Stmt body) {
		double num = lookupVariable(test);
		
		if (num != 0.0) {
			body.accept(this);
		}
	}

	public void input(String id) {
		consoleOutput.print("? ");
		double num = consoleInput.nextDouble();
		table.bind(id, new NumValue(num));
	}

	public void print(String id) {
		double num = lookupVariable(id);
		consoleOutput.println(num);
	}

	public void seq(List<Stmt> stmts) {
		for (Stmt stmt : stmts) {
			stmt.accept(this);
		}
	}

	public void sub(String id, Stmt body) {
		table.bind(id, new StmtValue(body));
	}

	public void until(String test, Stmt body) {
		double num = 0;

		do {
			body.accept(this);
			num = lookupVariable(test);
		} while (num == 0.0);
	}

	public void whileDo(String test, Stmt body) {
		double num = lookupVariable(test);
		while (num != 0.0) {
			body.accept(this);
			num = lookupVariable(test);
		}
	}

	private double lookupVariable(String id) {
		Value value = table.lookup(id);
		if (value == null) {
			throw new InterpreterException("Unknown variable " + id);
		}
		return value.asDouble();
	}

	private Stmt lookupStatement(String id) {
		Value value = table.lookup(id);
		if (value == null) {
			throw new InterpreterException("Unknown subprogram " + id);
		}
		return value.asStatement();
	}
}
