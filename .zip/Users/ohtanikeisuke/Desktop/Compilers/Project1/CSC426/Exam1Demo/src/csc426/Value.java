package csc426;

import csc426.ast.Stmt;

public interface Value {
	/**
	 * Extract a number from this value, or throw an exception if it is not a
	 * NumValue.
	 * 
	 * @return the number from this value
	 * @throws Exception
	 */
	public double asDouble() throws Exception;

	/**
	 * Extract a statement from this value, or throw an exception if it is not a
	 * StmtValue.
	 * 
	 * @return the statement object from this value
	 * @throws Exception 
	 */
	public Stmt asStatement() throws Exception;
}
