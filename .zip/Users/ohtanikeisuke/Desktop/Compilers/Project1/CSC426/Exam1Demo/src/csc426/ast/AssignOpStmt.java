package csc426.ast;

import csc426.NumValue;
import csc426.SymbolTable;
import csc426.Value;

public class AssignOpStmt implements Stmt {
	private String lhs;
	private String id1;
	private String op;
	private String id2;

	public AssignOpStmt(String lhs, String id1, String op, String id2) {
		this.lhs = lhs;
		this.id1 = id1;
		this.op = op;
		this.id2 = id2;
	}

	public String render(String indent) {
		return indent + "ASSIGN_OP " + lhs + " = " + id1 + " " + op + " " + id2 + "\n";
	}

	public void interpret(SymbolTable<Value> table) throws Exception {
		Value value1 = table.lookup(id1);
		Value value2 = table.lookup(id2);
		if (value1 == null) {
			throw new Exception("Unknown variable " + id1);
		}
		if (value2 == null) {
			throw new Exception("Unknown variable " + id2);
		}
		double num1 = value1.asDouble();
		double num2 = value2.asDouble();

		double result = 0;
		switch (op) {
		case "+":
			result = num1 + num2;
			break;

		case "-":
			result = num1 - num2;
			break;

		case "*":
			result = num1 * num2;
			break;

		case "/":
			result = num1 / num2;
			break;

		case "^":
			result = Math.pow(num1, num2);
			break;

		default:
			throw new Exception("Unknown operator " + op);
		}
		table.bind(lhs, new NumValue(result));
	}
}
