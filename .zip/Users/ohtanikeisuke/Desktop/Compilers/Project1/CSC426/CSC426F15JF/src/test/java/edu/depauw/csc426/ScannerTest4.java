package edu.depauw.csc426;

import static org.junit.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.io.Reader;

import org.junit.Test;

public class ScannerTest4 {

	/**
	 * A test of error messages. Uses System.setErr to redirect
	 * the standard error output to a ByteArrayOutputStream,
	 * which can then be examined.
	 * 
	 * test9.in is
-------
// Errors
/ Illegal comment
{bad characters: !@#$%^&}!@#$%^&
[]{}()|\\//The { and the } are OK
`~_:'",<>?{a closed comment


foo


}
{and an unclosed one


bar
-------
	 * @throws IOException 
	 */
	@Test
	public void test9() throws IOException {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		PrintStream err = new PrintStream(out);
		System.setErr(err);
		
		Reader in = new BufferedReader(new FileReader("test9.in"));
		Scanner scanner = new Scanner(in);

		Token t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(2, t.line);
		assertEquals(3, t.column);
		assertEquals("Illegal", t.lexeme);
		
		String expected1 = "Error: Malformed comment at line 2, column 1\n";
		assertEquals(expected1, out.toString());
		out.reset();
		
		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(2, t.line);
		assertEquals(11, t.column);
		assertEquals("comment", t.lexeme);
		
		String expected2 = "";
		assertEquals(expected2, out.toString());
		out.reset();
		
		t = scanner.next();
		assertEquals(TokenType.EOF, t.type);
		assertEquals(16, t.line);
		assertEquals(1, t.column);		
		
		String expected3 =
				"Error: Unexpected character (!) at line 3, column 26\n"
				+ "Error: Unexpected character (@) at line 3, column 27\n"
				+ "Error: Unexpected character (#) at line 3, column 28\n"
				+ "Error: Unexpected character ($) at line 3, column 29\n"
				+ "Error: Unexpected character (%) at line 3, column 30\n"
				+ "Error: Unexpected character (^) at line 3, column 31\n"
				+ "Error: Unexpected character (&) at line 3, column 32\n"
				+ "Error: Unexpected character ([) at line 4, column 1\n"
				+ "Error: Unexpected character (]) at line 4, column 2\n"
				+ "Error: Unexpected character (() at line 4, column 5\n"
				+ "Error: Unexpected character ()) at line 4, column 6\n"
				+ "Error: Unexpected character (|) at line 4, column 7\n"
				+ "Error: Unexpected character (\\) at line 4, column 8\n"
				+ "Error: Unexpected character (\\) at line 4, column 9\n"
				+ "Error: Unexpected character (`) at line 5, column 1\n"
				+ "Error: Unexpected character (~) at line 5, column 2\n"
				+ "Error: Unexpected character (_) at line 5, column 3\n"
				+ "Error: Unexpected character (:) at line 5, column 4\n"
				+ "Error: Unexpected character (') at line 5, column 5\n"
				+ "Error: Unexpected character (\") at line 5, column 6\n"
				+ "Error: Unexpected character (,) at line 5, column 7\n"
				+ "Error: Unexpected character (<) at line 5, column 8\n"
				+ "Error: Unexpected character (>) at line 5, column 9\n"
				+ "Error: Unexpected character (?) at line 5, column 10\n"
				+ "Error: Unclosed comment at line 12, column 1\n";
		assertEquals(expected3, out.toString());
		out.reset();
	}
}
