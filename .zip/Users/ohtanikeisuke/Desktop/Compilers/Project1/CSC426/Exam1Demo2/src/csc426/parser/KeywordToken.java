package csc426.parser;

public class KeywordToken implements Token {
	private String lexeme;
	private TokenType type;

	public KeywordToken(String lexeme) {
		this.lexeme = lexeme;		
		type = TokenType.valueOf(lexeme.toUpperCase());
	}

	@Override
	public TokenType getType() {
		return type;
	}

	@Override
	public String toString() {
		return type.toString();
	}

	@Override
	public String lexeme() {
		return lexeme;
	}
}
