package csc426;

import static org.junit.Assert.assertEquals;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.junit.Rule;
import org.junit.Test;
import org.junit.contrib.java.lang.system.Assertion;
import org.junit.contrib.java.lang.system.ExpectedSystemExit;
import org.junit.contrib.java.lang.system.SystemErrRule;
import org.junit.contrib.java.lang.system.SystemOutRule;

public class Project2Test {
	@Rule
	public final SystemOutRule systemOutRule = new SystemOutRule().enableLog().mute();

	@Rule
	public final SystemErrRule systemErrRule = new SystemErrRule().enableLog().mute();

	@Rule
	public final ExpectedSystemExit exit = ExpectedSystemExit.none();

	@Test
	public void test1() throws IOException {
		testFiles("resource/project2/test1");
	}

	@Test
	public void test2() throws IOException {
		testFiles("resource/project2/test2");
	}

	@Test
	public void test3() throws IOException {
		testFiles("resource/project2/test3");
	}

	@Test
	public void test4() throws IOException {
		testFilesWithExit("resource/project2/test4");
	}

	@Test
	public void test5() throws IOException {
		testFilesWithExit("resource/project2/test5");
	}

	@Test
	public void test6() throws IOException {
		testFiles("resource/project2/test6");
	}

	@Test
	public void test7() throws IOException {
		testFilesWithExit("resource/project2/test7");
	}

	private void testFiles(String name) throws FileNotFoundException, IOException {
		String expectOut = IOUtils.toString(new FileReader(name + ".out"));
		String expectErr = IOUtils.toString(new FileReader(name + ".err"));

		InputStream in = new FileInputStream(name + ".in");
		System.setIn(in);

		Project2.main(null);

		in.close();

		assertEquals(expectOut, systemOutRule.getLog());
		assertEquals(expectErr, systemErrRule.getLog());
	}

	private void testFilesWithExit(String name) throws FileNotFoundException, IOException {
		exit.expectSystemExitWithStatus(1);

		String expectOut = IOUtils.toString(new FileReader(name + ".out"));
		String expectErr = IOUtils.toString(new FileReader(name + ".err"));

		exit.checkAssertionAfterwards(new Assertion() {
			public void checkAssertion() {
				assertEquals(expectOut, systemOutRule.getLog());
				assertEquals(expectErr, systemErrRule.getLog());
			}
		});

		InputStream in = new FileInputStream(name + ".in");
		System.setIn(in);

		Project2.main(null);

		// will never reach here, since we expect it to call System.exit(1)
	}

}
