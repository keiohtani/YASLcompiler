package csc426.ast;

public class AssignIdStmt implements Stmt {
	private String lhs;
	private String id;

	public AssignIdStmt(String lhs, String id) {
		this.lhs = lhs;
		this.id = id;
	}

	public void accept(Visitor v) {
		v.assignId(lhs, id);
	}
}
