package edu.depauw.csc426

import scala.util.parsing.input._

import YASLScanner.lexical

/**
 * @author bhoward
 */
case class Token(tok: YASLTokens#Token, pos: Position) {
  override def toString: String = {
    val tokString = tok match {
      case lexical.ID(lexeme) => "ID " + lexeme
      case lexical.NUM(lexeme) => "NUM " + lexeme
      case _ => tok.toString
    }
    
    s"$tokString ${pos.line}:${pos.column}"
  }
}

class Scanner(in: Reader[Char]) {
  private var scanner = new lexical.Scanner(in)
  
  def next: Token = {
    if (scanner.atEnd) {
      Token(lexical.EOF, scanner.pos)
    } else {
      val tok = scanner.first
      val pos = scanner.pos
      scanner = scanner.rest
      Token(tok, pos)
    }
  }
}