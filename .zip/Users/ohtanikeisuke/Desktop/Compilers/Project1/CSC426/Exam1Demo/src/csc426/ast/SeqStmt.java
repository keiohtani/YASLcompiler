package csc426.ast;

import java.util.List;

import csc426.SymbolTable;
import csc426.Value;

public class SeqStmt implements Stmt {
	private List<Stmt> stmts;

	public SeqStmt(List<Stmt> stmts) {
		this.stmts = stmts;
	}

	public String render(String indent) {
		String result = indent + "SEQ\n";
		for (Stmt stmt : stmts) {
			result += stmt.render(indent + "  ");
		}
		return result;
	}

	public void interpret(SymbolTable<Value> table) throws Exception {
		for (Stmt stmt : stmts) {
			stmt.interpret(table);
		}
	}
}
