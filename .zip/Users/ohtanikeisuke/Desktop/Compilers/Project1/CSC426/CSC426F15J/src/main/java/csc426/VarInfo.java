package csc426;

public class VarInfo implements Info {
	public VarInfo(int level, int offset) {
		this.level = level;
		this.offset = offset;
	}

	public int level;
	public int offset;
}
