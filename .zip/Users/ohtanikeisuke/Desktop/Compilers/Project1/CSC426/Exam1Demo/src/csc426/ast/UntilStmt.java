package csc426.ast;

import csc426.SymbolTable;
import csc426.Value;

public class UntilStmt implements Stmt {
	private String test;
	private Stmt body;

	public UntilStmt(String test, Stmt body) {
		this.test = test;
		this.body = body;
	}

	public String render(String indent) {
		String result = indent + "UNTIL " + test + "\n";
		result += body.render(indent + "  ");
		return result;
	}

	public void interpret(SymbolTable<Value> table) throws Exception {
		double num = 0;

		do {
			body.interpret(table);

			Value value = table.lookup(test);
			if (value == null) {
				throw new Exception("Unknown variable " + test);
			}
			num = value.asDouble();
		} while (num == 0.0);
	}
}
