package csc426;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.io.Reader;
import java.util.Scanner;

import csc426.ast.Stmt;

public class Main {
	public static void main(String[] args) throws IOException {
		Scanner consoleInput = new Scanner(System.in);
		PrintStream consoleOutput = System.out;
		
		File source = null;
		if (args.length > 0) {
			source = new File(args[0]);
		} else {
			consoleOutput.print("Source file? ");
			String sourceFilename = consoleInput.nextLine();
			source = new File(sourceFilename);
		}
		
		Reader in = new FileReader(source);
		Lexer scanner = new Lexer(in);
		Parser parser = new Parser(scanner);

		Stmt s = null;
		try {
			s = parser.parseProgram();
		} catch (Exception e) {
			System.err.println("Parse error: " + e.getMessage());
			System.exit(1);
		}
		in.close();

		System.out.println("--- AST ---");
		System.out.print(s.render(""));
		System.out.println("-------");

		SymbolTable<Value> table = new SymbolTable<>();
		table.enter();
		try {
			s.interpret(table);
		} catch (Exception e) {
			System.err.println("Interpreter error: " + e.getMessage());
			System.exit(1);
		}
		table.exit();
		
		consoleInput.close();
	}
}
