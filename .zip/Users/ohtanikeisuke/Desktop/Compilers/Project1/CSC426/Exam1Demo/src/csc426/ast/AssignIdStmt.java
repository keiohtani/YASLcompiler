package csc426.ast;

import csc426.NumValue;
import csc426.SymbolTable;
import csc426.Value;

public class AssignIdStmt implements Stmt {
	private String lhs;
	private String id;

	public AssignIdStmt(String lhs, String id) {
		this.lhs = lhs;
		this.id = id;
	}

	public String render(String indent) {
		return indent + "ASSIGN_ID " + lhs + " = " + id + "\n";
	}

	public void interpret(SymbolTable<Value> table) throws Exception {
		Value value = table.lookup(id);
		if (value == null) {
			throw new Exception("Unknown variable " + id);
		}
		
		double num = value.asDouble();
		table.bind(lhs, new NumValue(num));
	}
}
