/*
 * Token.cpp
 *
 *  Created on: Aug 30, 2015
 *      Author: bhoward
 */

#include "Token.h"

#include <ostream>

std::ostream& operator<<(std::ostream& out, Token_Type type) {
	switch (type) {
	case ID:
		out << "ID";
		break;
	case NUM:
		out << "NUM";
		break;
	case PROGRAM:
		out << "PROGRAM";
		break;
	case CONST:
		out << "CONST";
		break;
	case BEGIN:
		out << "BEGIN";
		break;
	case PRINT:
		out << "PRINT";
		break;
	case END:
		out << "END";
		break;
	case DIV:
		out << "DIV";
		break;
	case MOD:
		out << "MOD";
		break;
	case SEMI:
		out << "SEMI";
		break;
	case PERIOD:
		out << "PERIOD";
		break;
	case PLUS:
		out << "PLUS";
		break;
	case MINUS:
		out << "MINUS";
		break;
	case STAR:
		out << "STAR";
		break;
	case ASSIGN:
		out << "ASSIGN";
		break;
	case EOFILE:
		out << "EOF";
		break;
	default:
		out << "ERROR";
		break;
	}

	return out;
}

std::ostream& operator<<(std::ostream& out, const Token& token) {
	out << token.type;

	if (token.type == ID || token.type == NUM) {
		out << " " << token.lexeme;
	}

	out << " " << token.line << ":" << token.column;

	return out;
}
