package edu.depauw.csc426

/**
 * @author bhoward
 */
class Machine(in: java.util.Scanner, out: java.io.PrintWriter) {
  val STACK_LIMIT = 1000000 // arbitrary

  type Program = List[Instruction]

  def run(program: Program): Unit = {
    val code = program.toVector :+ Halt
    val target: Map[String, Int] = Map(collectLabels(program, 0, Nil): _*)
    var PC = 0
    var SP = STACK_LIMIT
    val M = scala.collection.mutable.Map.empty[Int, Int].withDefaultValue(0)
    val display = scala.collection.mutable.Map.empty[Int, Int].withDefaultValue(0)
    var running = true

    def push(n: Int): Unit = {
      SP -= 1
      M(SP) = n
    }

    def pop(): Int = {
      if (SP >= STACK_LIMIT) {
        sys.error("Stack Empty")
      }
      SP += 1
      M(SP - 1)
    }

    while (running) {
      val instruction = code(PC)
      PC += 1
      instruction match {
        case Label(_) =>
        // skip
        case BranchZero(name) =>
          if (pop() == 0) {
            PC = target(name)
          }
        case BranchNeg(name) =>
          if (pop() < 0) {
            PC = target(name)
          }
        case Branch(name) =>
          PC = target(name)
        case Call(name) =>
          push(PC)
          PC = target(name)
        case Return =>
          PC = pop()
        case Reserve(n) =>
          SP -= n
        case Drop(n) =>
          SP += n
        case Enter(level) =>
          push(display(level))
          display(level) = SP
        case Exit(level) =>
          display(level) = pop()
        case Address(level, offset) =>
          push(display(level) + offset)
        case Load =>
          val addr = pop()
          push(M(addr))
        case Store =>
          val addr = pop()
          M(addr) = pop()
        case Constant(n) =>
          push(n)
        case Add =>
          val b = pop()
          val a = pop()
          push(a + b)
        case Sub =>
          val b = pop()
          val a = pop()
          push(a - b)
        case Mul =>
          val b = pop()
          val a = pop()
          push(a * b)
        case Div =>
          val b = pop()
          val a = pop()
          push(a / b)
        case Mod =>
          val b = pop()
          val a = pop()
          push(a % b)
        case ReadLine =>
          out.flush()
          in.nextLine()
        case ReadInt =>
          out.flush()
          push(Integer.parseInt(in.nextLine()))
        case WriteInt =>
          out.print(pop())
        case WriteChar =>
          out.write(pop())
        case WriteLine =>
          out.write('\n')
          out.flush()
        case Halt =>
          running = false
        case Dup =>
          val a = pop()
          push(a)
          push(a)
      }
    }
  }

  def collectLabels(program: Program,
    pc: Int,
    result: List[(String, Int)]): List[(String, Int)] = program match {
    case Nil => result
    case Label(name) :: rest => collectLabels(rest, pc + 1, (name -> (pc + 1)) :: result)
    case _ :: rest => collectLabels(rest, pc + 1, result)
  }
}
