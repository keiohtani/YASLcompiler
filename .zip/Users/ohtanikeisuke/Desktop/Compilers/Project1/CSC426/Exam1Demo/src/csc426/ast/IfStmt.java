package csc426.ast;

import csc426.SymbolTable;
import csc426.Value;

public class IfStmt implements Stmt {
	private String test;
	private Stmt body;
	
	public IfStmt(String test, Stmt body) {
		this.test = test;
		this.body = body;
	}

	public String render(String indent) {
		String result = indent + "IF " + test + "\n";
		result += body.render(indent + "  ");
		return result;
	}

	public void interpret(SymbolTable<Value> table) throws Exception {
		Value value = table.lookup(test);
		if (value == null) {
			throw new Exception("Unknown variable " + test);
		}
		
		if (value.asDouble() != 0.0) {
			body.interpret(table);
		}
	}
}
