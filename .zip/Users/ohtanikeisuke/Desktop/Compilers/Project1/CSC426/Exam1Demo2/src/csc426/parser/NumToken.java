package csc426.parser;

public class NumToken implements Token {
	private double value;
	
	public NumToken(double value) {
		this.value = value;
	}

	public TokenType getType() {
		return TokenType.NUM;
	}

	@Override
	public String toString() {
		return "NUM " + value;
	}

	@Override
	public String lexeme() {
		return Double.toString(value);
	}
}
