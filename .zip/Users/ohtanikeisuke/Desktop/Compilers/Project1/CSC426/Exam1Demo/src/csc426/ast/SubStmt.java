package csc426.ast;

import csc426.StmtValue;
import csc426.SymbolTable;
import csc426.Value;

public class SubStmt implements Stmt {
	private String id;
	private Stmt body;
	
	public SubStmt(String id, Stmt body) {
		this.id = id;
		this.body = body;
	}

	public String render(String indent) {
		String result = indent + "SUB " + id + "\n";
		result += body.render(indent + "  ");
		return result;
	}

	public void interpret(SymbolTable<Value> table) {
		table.bind(id, new StmtValue(body));
	}
}
