package csc426.interpret;

import csc426.ast.Stmt;

public class StmtValue implements Value {
	private Stmt stmt;
	
	public StmtValue(Stmt stmt) {
		this.stmt = stmt;
	}

	public double asDouble() throws InterpreterException {
		throw new InterpreterException("Attempt to use a statement as a number");
	}

	public Stmt asStatement() {
		return stmt;
	}
}
