package csc426.ast;

import java.util.List;

public class Renderer implements Visitor {
	private String indent;
	private StringBuilder builder;

	public Renderer() {
		this.indent = "";
		this.builder = new StringBuilder();
	}

	public void run(Stmt s) {
		s.accept(this);
	}

	public String getString() {
		return builder.toString();
	}

	public void assignId(String lhs, String id) {
		line("ASSIGN_ID " + lhs + " = " + id);
	}

	public void assignNum(String lhs, double num) {
		line("ASSIGN_NUM " + lhs + " = " + num);
	}

	public void assignOp(String lhs, String id1, String op, String id2) {
		line("ASSIGN_OP " + lhs + " = " + id1 + " " + op + " " + id2);
	}

	public void call(String id) {
		line("CALL " + id);
	}

	public void ifThen(String test, Stmt body) {
		line("IF " + test);
		indent();
		body.accept(this);
		outdent();
	}

	public void input(String id) {
		line("INPUT " + id);
	}

	public void print(String id) {
		line("PRINT " + id);
	}

	public void seq(List<Stmt> stmts) {
		line("SEQ");
		indent();
		for (Stmt stmt : stmts) {
			stmt.accept(this);
		}
		outdent();
	}

	public void sub(String id, Stmt body) {
		line("SUB " + id);
		indent();
		body.accept(this);
		outdent();
	}

	public void until(String test, Stmt body) {
		line("UNTIL " + test);
		indent();
		body.accept(this);
		outdent();
	}

	public void whileDo(String test, Stmt body) {
		line("WHILE " + test);
		indent();
		body.accept(this);
		outdent();
	}

	private void line(String s) {
		builder.append(indent).append(s).append('\n');
	}

	private void indent() {
		indent += "  ";
	}

	private void outdent() {
		indent = indent.substring(2);
	}
}
