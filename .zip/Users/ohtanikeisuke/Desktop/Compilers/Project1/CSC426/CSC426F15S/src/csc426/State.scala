package csc426

/**
 * Base class of states in the Mealy machine for lexical analysis of the YASL
 * subset. Starting with INITIAL_STATE, repeatedly call step(source) to get a
 * new state. If done returns true, then the Token is given by token;
 * otherwise, do source.advance() and repeat (see Scanner.next()).
 *
 * This is a Scala translation of the object-oriented state Java version.
 *
 * @author bhoward
 */
trait State {
  /**
   * Compute the appropriate next state from this state and the current
   * character of the source.
   *
   * @param source
   * @return the next State
   */
  /* (non-Javadoc)
 * @see csc426.State#step(csc426.Source)
 */
def step(source: Source): State

  /**
   * @return true if a token is ready to be emitted.
   */
  def done: Boolean = false

  /**
   * @return the emitted token if done() was true.
   */
  def token: Token = throw new IllegalStateException("Token only available from final state");
}

/**
 * Companion object with the "static" components of State.
 *
 * @author bhoward
 */
object State {
  /**
   * A String containing all of the characters that may be a single-character
   * operator or punctuation.
   */
  val OPCHARS: String = "+-*;.:(),";

  /**
   * A Map from lexeme to the corresponding TokenType, for all of the
   * "fixed lexeme" tokens.
   */
  val tokenMap: Map[String, TokenType] = Map(
    "program" -> PROGRAM,
    "const" -> CONST,
    "begin" -> BEGIN,
    "print" -> PRINT,
    "end" -> END,
    "div" -> DIV,
    "mod" -> MOD,
    "var" -> VAR,
    "int" -> INT,
    "bool" -> BOOL,
    "proc" -> PROC,
    "if" -> IF,
    "then" -> THEN,
    "else" -> ELSE,
    "while" -> WHILE,
    "do" -> DO,
    "prompt" -> PROMPT,
    "and" -> AND,
    "or" -> OR,
    "not" -> NOT,
    "true" -> TRUE,
    "false" -> FALSE,
    "+" -> PLUS,
    "-" -> MINUS,
    "*" -> STAR,
    "=" -> ASSIGN,
    "==" -> EQUAL,
    "<>" -> NOTEQUAL,
    "<=" -> LESSEQUAL,
    ">=" -> GREATEREQUAL,
    "<" -> LESS,
    ">" -> GREATER,
    ";" -> SEMI,
    "." -> PERIOD,
    ":" -> COLON,
    "(" -> LPAREN,
    ")" -> RPAREN,
    "," -> COMMA)

  /**
   * The starting state when trying to recognize a token. The type of token has
   * not yet been determined, so white space and comments will be skipped until
   * either a distinctive token-starting character is seen or the input is
   * exhausted.
   */
  case object InitialState extends State {
    def step(source: Source): State = {
      if (source.atEOF) {
        FinalState(source.line, source.column, "<EOF>", EOF)
      } else if (Character.isLetter(source.current)) {
        IdentState(source)
      } else if (source.current == '0') {
        ZeroState(source)
      } else if (Character.isDigit(source.current)) {
        NumState(source)
      } else if (OPCHARS.indexOf(source.current) >= 0) {
        OpState(source)
      } else if (source.current == '=') {
        EqualState(source)
      } else if (source.current == '<') {
        LessState(source)
      } else if (source.current == '>') {
        GreaterState(source)
      } else if (Character.isWhitespace(source.current)) {
        InitialState
      } else if (source.current == '/') {
        SlashState(source)
      } else if (source.current == '{') {
        BraceState(source)
      } else if (source.current == '"') {
        QuoteState(source)
      } else {
        Console.err.print(s"Error: Unexpected character (${source.current}) ");
        Console.err.println(s"at line ${source.line}, column ${source.column}");
        InitialState
      }
    }
  }

  /**
   * The final state when a token has been recognized. This will happen when the
   * current character of the source is one past the end of the token, so
   * source.advance() should not be called before starting to recognize the next
   * token.
   */
  case class FinalState(line: Int, column: Int, lexeme: String, ttype: TokenType) extends State {
    def step(source: Source): State = {
      // This should not be called
      null
    }

    override val done = true

    override val token = Token(line, column, ttype, lexeme)
  }

  /**
   * Base class of the states corresponding to the body of a token. Marks the
   * current position when created, and starts a lexeme buffer with the current
   * character from the source.
   */
  abstract class MarkState(source: Source) extends State {
    val line = source.line
    val column = source.column
    val buffer = new StringBuilder

    buffer.append(source.current)
  }

  /**
   * The state while recognizing an identifier or keyword. The same state object
   * is reused while the token is read; the "state" changes by appending
   * characters to the lexeme buffer.
   */
  case class IdentState(source: Source) extends MarkState(source) {
    def step(source: Source): State = {
      if (!source.atEOF && Character.isLetterOrDigit(source.current)) {
        buffer.append(source.current)
        this
      } else {
        val lexeme = buffer.toString
        val ttype = tokenMap.getOrElse(lexeme, ID)
        FinalState(line, column, lexeme, ttype)
      }
    }
  }

  /**
   * The state while recognizing a non-zero integer literal. The same state object
   * is reused while the token is read; the "state" changes by appending
   * characters to the lexeme buffer.
   */
  case class NumState(source: Source) extends MarkState(source) {
    def step(source: Source): State = {
      if (!source.atEOF && Character.isDigit(source.current)) {
        buffer.append(source.current);
        this
      } else {
        FinalState(line, column, buffer.toString, NUM)
      }
    }
  }

  /**
   * The state while recognizing a zero integer literal (since no other literals
   * may start with a leading zero).
   */
  case class ZeroState(source: Source) extends MarkState(source) {
    def step(source: Source): State = {
      FinalState(line, column, buffer.toString, NUM)
    }
  }

  /**
   * The state while recognizing a single-character operator or punctuation.
   */
  case class OpState(source: Source) extends MarkState(source) {
    def step(source: Source): State = {
      val lexeme = buffer.toString
      val ttype = tokenMap(lexeme)

      FinalState(line, column, lexeme, ttype)
    }
  }
  
  /**
   * The state while recognizing an operator that starts with =.
   */
  case class EqualState(source: Source) extends MarkState(source) {
    def step(source: Source): State = {
      if (!source.atEOF && source.current == '=') {
        EqualEqualState(line, column)
      } else {
        FinalState(line, column, "=", ASSIGN)
      }
    }
  }
  
  /**
   * The state while recognizing the == operator.
   */
  case class EqualEqualState(line: Int, column: Int) extends State {
    def step(source: Source): State = {
      FinalState(line, column, "==", EQUAL)
    }
  }

  /**
   * The state while recognizing an operator that starts with <.
   */
  case class LessState(source: Source) extends MarkState(source) {
    def step(source: Source): State = {
      if (!source.atEOF && source.current == '=') {
        LessEqualState(line, column)
      } else if (!source.atEOF && source.current == '>') {
        LessGreaterState(line, column)
      } else {
        FinalState(line, column, "<", LESS)
      }
    }
  }
  
  /**
   * The state while recognizing the <= operator.
   */
  case class LessEqualState(line: Int, column: Int) extends State {
    def step(source: Source): State = {
      FinalState(line, column, "<=", LESSEQUAL)
    }
  }

  /**
   * The state while recognizing the <> operator.
   */
  case class LessGreaterState(line: Int, column: Int) extends State {
    def step(source: Source): State = {
      FinalState(line, column, "<>", NOTEQUAL)
    }
  }

  /**
   * The state while recognizing an operator that starts with >.
   */
  case class GreaterState(source: Source) extends MarkState(source) {
    def step(source: Source): State = {
      if (!source.atEOF && source.current == '=') {
        GreaterEqualState(line, column)
      } else {
        FinalState(line, column, ">", GREATER)
      }
    }
  }
  
  /**
   * The state while recognizing the >= operator.
   */
  case class GreaterEqualState(line: Int, column: Int) extends State {
    def step(source: Source): State = {
      FinalState(line, column, ">=", GREATEREQUAL)
    }
  }

  /**
   * The state while starting to recognize an end-of-line comment, starting with
   * two forward slashes. It is an error to have only a single slash.
   */
  case class SlashState(source: Source) extends State {
    val line = source.line
    val column = source.column

    def step(source: Source): State = {
      if (!source.atEOF && source.current == '/') {
        Slash2State
      } else {
        Console.err.print("Error: Malformed comment ")
        Console.err.println(s"at line $line, column $column")
        InitialState
      }
    }
  }

  /**
   * The state while recognizing the body of an end-of-line comment, starting with
   * two forward slashes and continuing to the next newline.
   */
  case object Slash2State extends State {
    def step(source: Source): State = {
      if (source.atEOF || source.current == '\n') {
        InitialState
      } else {
        this
      }
    }
  }

  /**
   * The state while recognizing the body of a brace-delimited comment, starting
   * with a left curly brace ({) and continuing to the first right curly brace
   * (}). It is an error to have an unclosed comment at the end of input.
   */
  case class BraceState(source: Source) extends State {
    val line = source.line
    val column = source.column

    def step(source: Source): State = {
      if (source.atEOF) {
        Console.err.print("Error: Unclosed comment ")
        Console.err.println(s"at line $line, column $column")
        InitialState
      } else if (source.current == '}') {
        InitialState
      } else {
        this
      }
    }
  }
  
  /**
   * The state while recognizing a string literal, starting with a double-quote
   * (") and continuing to the next double-quote that is not paired with an
   * immediately following double-quote (such pairs are reduced to a single
   * double-quote as part of the string). It is an error to have an unclosed
   * string literal at the end of input.
   */
  case class QuoteState(source: Source) extends MarkState(source) {
    def step(source: Source): State = {
      if (source.atEOF) {
        Console.err.print("Error: Unclosed string literal ")
        Console.err.println(s"at line $line, column $column")
        InitialState
      } else if (source.current == '"') {
        Quote2State(this)
      } else {
        buffer.append(source.current)
        this
      }
    }
  }
  
  /**
   * The state when a double-quote is seen while processing a string literal.
   * If another double-quote follows it, then the literal continues and just
   * one double-quote is added to the string; otherwise, it is the end of the
   * string.
   */
  case class Quote2State(parent: QuoteState) extends State {
    def step(source: Source): State = {
      if (source.atEOF || source.current != '"') {
        FinalState(parent.line, parent.column, parent.buffer.substring(1), STRING)
      } else {
        parent.buffer.append(source.current)
        parent
      }
    }
  }
}