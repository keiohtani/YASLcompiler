package csc426.parser;

public class EOFToken implements Token {
	public TokenType getType() {
		return TokenType.EOF;
	}
	
	@Override
	public String toString() {
		return "<EOF>";
	}

	@Override
	public String lexeme() {
		return null;
	}
}
