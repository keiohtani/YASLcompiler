package csc426

/**
 * Main class for Project 1 -- Scanner for a Subset of YASL (Fall 2015). Scans
 * tokens from standard input and prints the token stream to standard output.
 * 
 * @author bhoward
 */
object Project1 extends App {
  val scanner = new Scanner(Console.in)

  var token = scanner.next()
  while (token.ttype != EOF) {
    println(token)
    token = scanner.next()
  }
  
  println(token)
  
  scanner.close()
}