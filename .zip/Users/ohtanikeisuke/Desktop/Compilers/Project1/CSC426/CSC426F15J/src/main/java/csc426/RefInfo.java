package csc426;

public class RefInfo implements Info {
	public RefInfo(int level, int offset) {
		this.level = level;
		this.offset = offset;
	}

	public int level;
	public int offset;
}
