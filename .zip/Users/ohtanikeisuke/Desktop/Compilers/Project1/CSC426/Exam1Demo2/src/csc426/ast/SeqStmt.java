package csc426.ast;

import java.util.List;

public class SeqStmt implements Stmt {
	private List<Stmt> stmts;

	public SeqStmt(List<Stmt> stmts) {
		this.stmts = stmts;
	}

	public void accept(Visitor v) {
		v.seq(stmts);
	}
}
