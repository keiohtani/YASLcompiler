package csc426.parser;

public class IdToken implements Token {
	private String lexeme;
	
	public IdToken(String lexeme) {
		this.lexeme = lexeme;
	}

	public TokenType getType() {
		return TokenType.ID;
	}
	
	@Override
	public String toString() {
		return "ID " + lexeme;
	}

	@Override
	public String lexeme() {
		return lexeme;
	}
}
