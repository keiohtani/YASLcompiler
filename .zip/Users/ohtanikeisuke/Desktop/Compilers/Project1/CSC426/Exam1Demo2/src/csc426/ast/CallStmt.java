package csc426.ast;

public class CallStmt implements Stmt {
	private String id;

	public CallStmt(String id) {
		this.id = id;
	}

	public void accept(Visitor v) {
		v.call(id);
	}
}
