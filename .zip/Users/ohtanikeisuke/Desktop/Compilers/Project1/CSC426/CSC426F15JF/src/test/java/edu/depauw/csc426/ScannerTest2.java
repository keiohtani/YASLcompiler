package edu.depauw.csc426;

import static org.junit.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

import org.junit.Test;

public class ScannerTest2 {
	/**
	 * A (short) realistic YASL program. This is the example
	 * from Moodle for Project 1.
	 * 
	 * test3.in is
-------
program demo1;
{ Declare some constants }
const x = 6;
const y = 7;
begin
  print x * y; // should print 42
end.
-------
	 * @throws IOException 
	 */
	@Test
	public void test3() throws IOException {
		Reader in = new BufferedReader(new FileReader("test3.in"));
		Scanner scanner = new Scanner(in);

		Token t = scanner.next();
		assertEquals(TokenType.PROGRAM, t.type);
		assertEquals(1, t.line);
		assertEquals(1, t.column);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(1, t.line);
		assertEquals(9, t.column);
		assertEquals("demo1", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.SEMI, t.type);
		assertEquals(1, t.line);
		assertEquals(14, t.column);

		t = scanner.next();
		assertEquals(TokenType.CONST, t.type);
		assertEquals(3, t.line);
		assertEquals(1, t.column);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(3, t.line);
		assertEquals(7, t.column);
		assertEquals("x", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ASSIGN, t.type);
		assertEquals(3, t.line);
		assertEquals(9, t.column);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(3, t.line);
		assertEquals(11, t.column);
		assertEquals("6", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.SEMI, t.type);
		assertEquals(3, t.line);
		assertEquals(12, t.column);

		t = scanner.next();
		assertEquals(TokenType.CONST, t.type);
		assertEquals(4, t.line);
		assertEquals(1, t.column);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(4, t.line);
		assertEquals(7, t.column);
		assertEquals("y", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ASSIGN, t.type);
		assertEquals(4, t.line);
		assertEquals(9, t.column);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(4, t.line);
		assertEquals(11, t.column);
		assertEquals("7", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.SEMI, t.type);
		assertEquals(4, t.line);
		assertEquals(12, t.column);

		t = scanner.next();
		assertEquals(TokenType.BEGIN, t.type);
		assertEquals(5, t.line);
		assertEquals(1, t.column);

		t = scanner.next();
		assertEquals(TokenType.PRINT, t.type);
		assertEquals(6, t.line);
		assertEquals(3, t.column);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(6, t.line);
		assertEquals(9, t.column);
		assertEquals("x", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.STAR, t.type);
		assertEquals(6, t.line);
		assertEquals(11, t.column);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(6, t.line);
		assertEquals(13, t.column);
		assertEquals("y", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.SEMI, t.type);
		assertEquals(6, t.line);
		assertEquals(14, t.column);

		t = scanner.next();
		assertEquals(TokenType.END, t.type);
		assertEquals(7, t.line);
		assertEquals(1, t.column);

		t = scanner.next();
		assertEquals(TokenType.PERIOD, t.type);
		assertEquals(7, t.line);
		assertEquals(4, t.column);

		t = scanner.next();
		assertEquals(TokenType.EOF, t.type);
		assertEquals(8, t.line);
		assertEquals(1, t.column);
	}

	/**
	 * A (slightly longer) realistic YASL program. This is the example
	 * from Moodle for Project 2.
	 * 
	 * test4.in is
-------
program demo2;
{ Declare some constants }
const x = 6;
const y = 7;
begin
  print x * y; // should print 42
  print 12 div y * y + 12 mod y - 12; // should print 0
end.

-------
	 * @throws IOException 
	 */
	@Test
	public void test4() throws IOException {
		Reader in = new BufferedReader(new FileReader("test4.in"));
		Scanner scanner = new Scanner(in);

		Token t = scanner.next();
		assertEquals(TokenType.PROGRAM, t.type);
		assertEquals(1, t.line);
		assertEquals(1, t.column);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(1, t.line);
		assertEquals(9, t.column);
		assertEquals("demo2", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.SEMI, t.type);
		assertEquals(1, t.line);
		assertEquals(14, t.column);

		t = scanner.next();
		assertEquals(TokenType.CONST, t.type);
		assertEquals(3, t.line);
		assertEquals(1, t.column);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(3, t.line);
		assertEquals(7, t.column);
		assertEquals("x", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ASSIGN, t.type);
		assertEquals(3, t.line);
		assertEquals(9, t.column);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(3, t.line);
		assertEquals(11, t.column);
		assertEquals("6", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.SEMI, t.type);
		assertEquals(3, t.line);
		assertEquals(12, t.column);

		t = scanner.next();
		assertEquals(TokenType.CONST, t.type);
		assertEquals(4, t.line);
		assertEquals(1, t.column);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(4, t.line);
		assertEquals(7, t.column);
		assertEquals("y", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ASSIGN, t.type);
		assertEquals(4, t.line);
		assertEquals(9, t.column);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(4, t.line);
		assertEquals(11, t.column);
		assertEquals("7", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.SEMI, t.type);
		assertEquals(4, t.line);
		assertEquals(12, t.column);

		t = scanner.next();
		assertEquals(TokenType.BEGIN, t.type);
		assertEquals(5, t.line);
		assertEquals(1, t.column);

		t = scanner.next();
		assertEquals(TokenType.PRINT, t.type);
		assertEquals(6, t.line);
		assertEquals(3, t.column);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(6, t.line);
		assertEquals(9, t.column);
		assertEquals("x", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.STAR, t.type);
		assertEquals(6, t.line);
		assertEquals(11, t.column);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(6, t.line);
		assertEquals(13, t.column);
		assertEquals("y", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.SEMI, t.type);
		assertEquals(6, t.line);
		assertEquals(14, t.column);

		t = scanner.next();
		assertEquals(TokenType.PRINT, t.type);
		assertEquals(7, t.line);
		assertEquals(3, t.column);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(7, t.line);
		assertEquals(9, t.column);
		assertEquals("12", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.DIV, t.type);
		assertEquals(7, t.line);
		assertEquals(12, t.column);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(7, t.line);
		assertEquals(16, t.column);
		assertEquals("y", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.STAR, t.type);
		assertEquals(7, t.line);
		assertEquals(18, t.column);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(7, t.line);
		assertEquals(20, t.column);
		assertEquals("y", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.PLUS, t.type);
		assertEquals(7, t.line);
		assertEquals(22, t.column);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(7, t.line);
		assertEquals(24, t.column);
		assertEquals("12", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.MOD, t.type);
		assertEquals(7, t.line);
		assertEquals(27, t.column);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(7, t.line);
		assertEquals(31, t.column);
		assertEquals("y", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.MINUS, t.type);
		assertEquals(7, t.line);
		assertEquals(33, t.column);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(7, t.line);
		assertEquals(35, t.column);
		assertEquals("12", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.SEMI, t.type);
		assertEquals(7, t.line);
		assertEquals(37, t.column);

		t = scanner.next();
		assertEquals(TokenType.END, t.type);
		assertEquals(8, t.line);
		assertEquals(1, t.column);

		t = scanner.next();
		assertEquals(TokenType.PERIOD, t.type);
		assertEquals(8, t.line);
		assertEquals(4, t.column);

		t = scanner.next();
		assertEquals(TokenType.EOF, t.type);
		assertEquals(10, t.line);
		assertEquals(1, t.column);
	}
}
