package edu.depauw.csc426

import scala.util.parsing.combinator.lexical.Lexical
import scala.util.parsing.input.CharArrayReader.EofCh

/**
 * Based on scala.util.parsing.combinator.lexical.StdLexical
 * @author bhoward
 */
class YASLScanner extends Lexical with YASLTokens {
  def token: Parser[Token] =
    (letter ~ rep(letter | digit) ^^ { case first ~ rest => processIdent(first :: rest mkString "") }
      | nonzeroDigit ~ rep(digit) ^^ { case first ~ rest => NUM(first :: rest mkString "") }
      | '0' ^^^ NUM("0")
      | '+' ^^^ PLUS
      | '-' ^^^ MINUS
      | '*' ^^^ STAR
      | '=' ^^^ ASSIGN
      | ';' ^^^ SEMI
      | '.' ^^^ PERIOD
      | EofCh ^^^ EOF
      | failure("illegal character"))

  def nonzeroDigit = elem("non-zero digit", c => (c.isDigit && c != '0'))

  def whitespace: Parser[Any] = rep(
    whitespaceChar
      | '{' ~ rep(chrExcept(EofCh, '}')) ~ '}'
      | '/' ~ '/' ~ rep(chrExcept(EofCh, '\n'))
      | '{' ~ failure("unclosed comment"))

  val reserved = Map(
    "program" -> PROGRAM,
    "const" -> CONST,
    "begin" -> BEGIN,
    "print" -> PRINT,
    "end" -> END,
    "div" -> DIV,
    "mod" -> MOD)

  protected def processIdent(name: String) =
    if (reserved contains name) reserved(name) else ID(name)
}

object YASLScanner {
  val lexical = new YASLScanner
}