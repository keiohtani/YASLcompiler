package csc426;

public class ConstInfo implements Info {
	public ConstInfo(int value) {
		this.value = value;
	}

	public int value;
}
