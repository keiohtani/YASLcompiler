package csc426;

import static org.junit.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

import org.junit.Test;

import csc426.parser.Position;
import csc426.parser.ErrorLog;
import csc426.parser.Lexer;
import csc426.parser.Token;
import csc426.parser.TokenType;

public class ScannerTest2 {
	/**
	 * A (short) realistic YASL program. This is the example
	 * from Moodle for Project 1.
	 * 
	 * test3.in is
-------
program demo1;
{ Declare some constants }
const x = 6;
const y = 7;
begin
  print x * y; // should print 42
end.
-------
	 * @throws IOException 
	 */
	@Test
	public void test3() throws IOException {
		Reader in = new BufferedReader(new FileReader("resource/project1/test3.in"));
		Lexer scanner = new Lexer(in, new ErrorLog());

		Token t = scanner.next();
		assertEquals(TokenType.PROGRAM, t.type);
		assertEquals(new Position(1, 1), t.position);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(1, 9), t.position);
		assertEquals("demo1", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.SEMI, t.type);
		assertEquals(new Position(1, 14), t.position);

		t = scanner.next();
		assertEquals(TokenType.CONST, t.type);
		assertEquals(new Position(3, 1), t.position);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(3, 7), t.position);
		assertEquals("x", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ASSIGN, t.type);
		assertEquals(new Position(3, 9), t.position);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(3, 11), t.position);
		assertEquals("6", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.SEMI, t.type);
		assertEquals(new Position(3, 12), t.position);

		t = scanner.next();
		assertEquals(TokenType.CONST, t.type);
		assertEquals(new Position(4, 1), t.position);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(4, 7), t.position);
		assertEquals("y", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ASSIGN, t.type);
		assertEquals(new Position(4, 9), t.position);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(4, 11), t.position);
		assertEquals("7", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.SEMI, t.type);
		assertEquals(new Position(4, 12), t.position);

		t = scanner.next();
		assertEquals(TokenType.BEGIN, t.type);
		assertEquals(new Position(5, 1), t.position);

		t = scanner.next();
		assertEquals(TokenType.PRINT, t.type);
		assertEquals(new Position(6, 3), t.position);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(6, 9), t.position);
		assertEquals("x", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.STAR, t.type);
		assertEquals(new Position(6, 11), t.position);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(6, 13), t.position);
		assertEquals("y", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.SEMI, t.type);
		assertEquals(new Position(6, 14), t.position);

		t = scanner.next();
		assertEquals(TokenType.END, t.type);
		assertEquals(new Position(7, 1), t.position);

		t = scanner.next();
		assertEquals(TokenType.PERIOD, t.type);
		assertEquals(new Position(7, 4), t.position);

		t = scanner.next();
		assertEquals(TokenType.EOF, t.type);
		assertEquals(new Position(8, 1), t.position);
	}

	/**
	 * A (slightly longer) realistic YASL program. This is the example
	 * from Moodle for Project 2.
	 * 
	 * test4.in is
-------
program demo2;
{ Declare some constants }
const x = 6;
const y = 7;
begin
  print x * y; // should print 42
  print 12 div y * y + 12 mod y - 12; // should print 0
end.

-------
	 * @throws IOException 
	 */
	@Test
	public void test4() throws IOException {
		Reader in = new BufferedReader(new FileReader("resource/project1/test4.in"));
		Lexer scanner = new Lexer(in, new ErrorLog());

		Token t = scanner.next();
		assertEquals(TokenType.PROGRAM, t.type);
		assertEquals(new Position(1, 1), t.position);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(1, 9), t.position);
		assertEquals("demo2", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.SEMI, t.type);
		assertEquals(new Position(1, 14), t.position);

		t = scanner.next();
		assertEquals(TokenType.CONST, t.type);
		assertEquals(new Position(3, 1), t.position);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(3, 7), t.position);
		assertEquals("x", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ASSIGN, t.type);
		assertEquals(new Position(3, 9), t.position);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(3, 11), t.position);
		assertEquals("6", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.SEMI, t.type);
		assertEquals(new Position(3, 12), t.position);

		t = scanner.next();
		assertEquals(TokenType.CONST, t.type);
		assertEquals(new Position(4, 1), t.position);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(4, 7), t.position);
		assertEquals("y", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ASSIGN, t.type);
		assertEquals(new Position(4, 9), t.position);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(4, 11), t.position);
		assertEquals("7", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.SEMI, t.type);
		assertEquals(new Position(4, 12), t.position);

		t = scanner.next();
		assertEquals(TokenType.BEGIN, t.type);
		assertEquals(new Position(5, 1), t.position);

		t = scanner.next();
		assertEquals(TokenType.PRINT, t.type);
		assertEquals(new Position(6, 3), t.position);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(6, 9), t.position);
		assertEquals("x", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.STAR, t.type);
		assertEquals(new Position(6, 11), t.position);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(6, 13), t.position);
		assertEquals("y", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.SEMI, t.type);
		assertEquals(new Position(6, 14), t.position);

		t = scanner.next();
		assertEquals(TokenType.PRINT, t.type);
		assertEquals(new Position(7, 3), t.position);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(7, 9), t.position);
		assertEquals("12", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.DIV, t.type);
		assertEquals(new Position(7, 12), t.position);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(7, 16), t.position);
		assertEquals("y", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.STAR, t.type);
		assertEquals(new Position(7, 18), t.position);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(7, 20), t.position);
		assertEquals("y", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.PLUS, t.type);
		assertEquals(new Position(7, 22), t.position);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(7, 24), t.position);
		assertEquals("12", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.MOD, t.type);
		assertEquals(new Position(7, 27), t.position);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(7, 31), t.position);
		assertEquals("y", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.MINUS, t.type);
		assertEquals(new Position(7, 33), t.position);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(7, 35), t.position);
		assertEquals("12", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.SEMI, t.type);
		assertEquals(new Position(7, 37), t.position);

		t = scanner.next();
		assertEquals(TokenType.END, t.type);
		assertEquals(new Position(8, 1), t.position);

		t = scanner.next();
		assertEquals(TokenType.PERIOD, t.type);
		assertEquals(new Position(8, 4), t.position);

		t = scanner.next();
		assertEquals(TokenType.EOF, t.type);
		assertEquals(new Position(10, 1), t.position);
	}
}
