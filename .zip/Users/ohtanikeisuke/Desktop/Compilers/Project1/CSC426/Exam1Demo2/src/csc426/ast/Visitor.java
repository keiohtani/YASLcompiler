package csc426.ast;

import java.util.List;

public interface Visitor {
	void assignId(String lhs, String id);

	void assignNum(String lhs, double num);

	void assignOp(String lhs, String id1, String op, String id2);

	void call(String id);

	void ifThen(String test, Stmt body);

	void input(String id);

	void print(String id);

	void seq(List<Stmt> stmts);

	void sub(String id, Stmt body);

	void until(String test, Stmt body);

	void whileDo(String test, Stmt body);
}
