package csc426;

public abstract class Code {
	private int sequence = 0;
	private StringBuilder builder = new StringBuilder();

	@Override
	public String toString() {
		finish();
		return builder.toString();
	}

	public String newLabel() {
		return "_" + (sequence++);
	}

	public void lvalue(String id, SymbolTable<Info> table) {
		Info info;
		try {
			info = table.lookup(id);
			if (info instanceof VarInfo) {
				VarInfo vi = (VarInfo) info;
				address(vi.level, vi.offset);
			} else {
				RefInfo ri = (RefInfo) info;
				address(ri.level, ri.offset);
				load();
			}
		} catch (TableError e) {
			// this shouldn't happen
		}
	}
	
	protected void appendLine(String line) {
		builder.append(line);
		builder.append("\n");
	}

	abstract void print(String message);
	abstract void load();
	abstract void store();
	abstract void address(int level, int offset);
	abstract void halt();
	abstract void branch(String s);
	abstract void branchzero(String s);
	abstract void branchneg(String s);
	abstract void call(String s);
	abstract void ret();
	abstract void label(String s);
	abstract void enter(int level);
	abstract void exit(int level);
	abstract void reserve(int n);
	abstract void drop(int n);
	abstract void readline();
	abstract void readint();
	abstract void writeline();
	abstract void writeint();
	abstract void writechar();
	abstract void constant(int n);
	abstract void add();
	abstract void sub();
	abstract void mul();
	abstract void div();
	abstract void mod();
	
	abstract void finish();
}