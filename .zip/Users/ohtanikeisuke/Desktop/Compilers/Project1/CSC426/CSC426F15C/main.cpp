/*
 * main.cpp
 *
 *  Created on: Aug 31, 2015
 *      Author: bhoward
 */

#include "Scanner.h"

#include <iostream>

int main() {
	Scanner scanner(std::cin);

	Token token;
	do {
		token = scanner.next();
		std::cout << token << std::endl;
	} while (token.type != EOFILE);
}
