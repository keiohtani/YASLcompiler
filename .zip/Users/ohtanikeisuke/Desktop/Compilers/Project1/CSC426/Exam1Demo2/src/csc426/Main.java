package csc426;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.io.Reader;
import java.util.Scanner;

import csc426.ast.Renderer;
import csc426.ast.Stmt;
import csc426.interpret.Interpreter;
import csc426.interpret.InterpreterException;
import csc426.parser.Lexer;
import csc426.parser.Parser;
import csc426.parser.ParserException;

public class Main {
	public static void main(String[] args) throws IOException {
		Scanner consoleInput = new Scanner(System.in);
		PrintStream consoleOutput = System.out;
		PrintStream consoleError = System.err;

		File source = null;
		if (args.length > 0) {
			source = new File(args[0]);
		} else {
			consoleOutput.print("Source file? ");
			String sourceFilename = consoleInput.nextLine();
			source = new File(sourceFilename);
		}

		try {
			Reader in = new FileReader(source);

			Lexer scanner = new Lexer(in);
			Parser parser = new Parser(scanner);
			Stmt s = parser.parseProgram();

			in.close();

			consoleOutput.println("--- AST ---");
			Renderer renderer = new Renderer();
			renderer.run(s);
			consoleOutput.print(renderer.getString());
			consoleOutput.println("-------");

			Interpreter interpreter = new Interpreter(consoleInput, consoleOutput);
			interpreter.run(s);
		} catch (ParserException e) {
			consoleError.println("Parse error: " + e.getMessage());
			System.exit(1);
		} catch (InterpreterException e) {
			consoleError.println("Interpreter error: " + e.getMessage());
			System.exit(1);
		}

		consoleInput.close();
	}
}
