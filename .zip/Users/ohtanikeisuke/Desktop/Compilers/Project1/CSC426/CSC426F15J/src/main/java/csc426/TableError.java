package csc426;

@SuppressWarnings("serial")
public class TableError extends Exception {
	public TableError(String message) {
		super(message);
	}
}
