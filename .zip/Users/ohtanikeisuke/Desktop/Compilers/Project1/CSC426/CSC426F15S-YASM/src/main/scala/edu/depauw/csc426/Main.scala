package edu.depauw.csc426

import java.util.Scanner
import java.io.PrintWriter
import java.io.FileReader
import java.io.FileWriter

/**
 * @author bhoward
 */
object Main extends App {
  if (args.length < 1) {
    sys.error("Required file name missing")
  }

  val filein = new FileReader(args(0))
  val program = Parser.parse(filein)
  filein.close()

  if (args.length == 1) {
    val in = new Scanner(Console.in)
    val out = new PrintWriter(Console.out)
    val machine = new Machine(in, out)

    machine.run(program)
  } else {
    val program2 = Optimizer(program)
    val pep = program2 flatMap { instruction =>
      ("; " + instruction) :: instruction.toPep9
    }
    val pep2 = PepOptimizer(pep)

    val fileout = new FileWriter(args(1))
    pep2 foreach { stmt =>
      fileout.write(stmt + "\n")
    }
    fileout.write(Instruction.runtime)
    fileout.close()
  }
}