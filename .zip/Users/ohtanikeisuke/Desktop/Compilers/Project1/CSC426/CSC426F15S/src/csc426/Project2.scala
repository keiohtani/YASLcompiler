package csc426

import scala.collection.mutable.{ HashMap, Stack }

/**
 * @author bhoward
 */
object Project2 extends App {
  val lookahead = new Lookahead(new Scanner(Console.in))

  val constant = new HashMap[String, String]

  lookahead.matchType(PROGRAM)
  lookahead.matchType(ID)
  lookahead.matchType(SEMI)

  // Process the const declarations
  while (lookahead.check(CONST)) {
    lookahead.skip()
    val id = lookahead.matchType(ID)
    lookahead.matchType(ASSIGN)
    val num = lookahead.matchType(NUM)
    lookahead.matchType(SEMI)

    constant += id.lexeme -> num.lexeme
  }

  lookahead.matchType(BEGIN)

  // Process the print statements
  while (lookahead.check(PRINT)) {
    lookahead.skip()
    val stack = new Stack[TokenType]
    stack.push(PRINT)

    while (!lookahead.check(SEMI)) {
      if (lookahead.check(NUM)) {
        val num = lookahead.skip()
        println(num.lexeme)
      } else if (lookahead.check(ID)) {
        val id = lookahead.skip()
        if (constant.contains(id.lexeme)) {
          println(constant(id.lexeme))
        } else {
          Console.err.println(s"Error: Unknown identifier ${id.lexeme}")
          sys.exit(1)
        }
      } else {
        val op = lookahead.skip()
        val prec = precedence(op.ttype)
        while (!stack.isEmpty && prec <= precedence(stack.top)) {
          println(operator(stack.pop()))
        }
        stack.push(op.ttype)
      }
    }

    lookahead.skip()
    while (!stack.isEmpty) {
      println(operator(stack.pop()))
    }
  }

  lookahead.matchType(END)
  lookahead.matchType(PERIOD)
  lookahead.matchType(EOF)

  def operator(ttype: TokenType): String = ttype match {
    case PRINT => "PRINT"
    case PLUS => "+"
    case MINUS => "-"
    case STAR => "*"
    case DIV => "DIV"
    case MOD => "MOD"
    case _ =>
      Console.err.println(s"Error: Expected an operator; found $ttype")
      sys.exit(1)
  }

  def precedence(ttype: TokenType): Int = ttype match {
    case PRINT => 0
    case PLUS => 1
    case MINUS => 1
    case STAR => 2
    case DIV => 2
    case MOD => 2
    case _ =>
      Console.err.println(s"Error: Expected an operator; found $ttype")
      sys.exit(1)
  }
}