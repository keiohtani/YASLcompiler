package edu.depauw.csc426

import scala.util.parsing.combinator._
import java.io.Reader


/**
 * @author bhoward
 */
object Parser extends RegexParsers {
  type P[T] = Parser[T]
  type Program = List[Instruction]
  
  lazy val program: P[Program] = rep(instr)
  
  lazy val instr: P[Instruction] =
    ( "LABEL" ~ ident ^^ {case _ ~ id => Label(id)}
    | "BRANCHZERO" ~ ident ^^ {case _ ~ id => BranchZero(id)}
    | "BRANCHNEG" ~ ident ^^ {case _ ~ id => BranchNeg(id)}
    | "BRANCH" ~ ident ^^ {case _ ~ id => Branch(id)}
    | "CALL" ~ ident ^^ {case _ ~ id => Call(id)}
    | "RETURN" ^^ {case _ => Return}
    | "RESERVE" ~ num ^^ {case _ ~ n => Reserve(n)}
    | "DROP" ~ num ^^ {case _ ~ n => Drop(n)}
    | "ENTER" ~ num ^^ {case _ ~ n => Enter(n)}
    | "EXIT" ~ num ^^ {case _ ~ n => Exit(n)}
    | "ADDRESS" ~ num ~ "," ~ num ^^ {case _ ~ m ~ _ ~ n => Address(m, n)}
    | "LOAD" ^^ {case _ => Load}
    | "STORE" ^^ {case _ => Store}
    | "CONSTANT" ~ num ^^ {case _ ~ n => Constant(n)}
    | "ADD" ^^ {case _ => Add}
    | "SUB" ^^ {case _ => Sub}
    | "MUL" ^^ {case _ => Mul}
    | "DIV" ^^ {case _ => Div}
    | "MOD" ^^ {case _ => Mod}
    | "READLINE" ^^ {case _ => ReadLine}
    | "READINT" ^^ {case _ => ReadInt}
    | "WRITEINT" ^^ {case _ => WriteInt}
    | "WRITECHAR" ^^ {case _ => WriteChar}
    | "WRITELINE" ^^ {case _ => WriteLine}
    | "HALT" ^^ {case _ => Halt}
    )
  
  val ident: Parser[String] = """[A-Za-z_][A-Za-z0-9_]*""".r
  
  val num: Parser[Int] = """-?[1-9][0-9]*|0""".r ^^ {case s => Integer.parseInt(s)}

  override val whiteSpace = """\s+""".r

  def apply(in: String) = parseAll(program, in)
  
  def parse(in: Reader): Program = parseAll(program, in) match {
    case Success(result, _) => result
    case ns: NoSuccess => sys.error(ns.msg)
  }
}