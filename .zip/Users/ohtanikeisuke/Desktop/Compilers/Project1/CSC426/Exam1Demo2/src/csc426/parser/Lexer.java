package csc426.parser;

import java.io.IOException;
import java.io.Reader;
import java.io.StreamTokenizer;
import java.util.HashSet;
import java.util.Set;

public class Lexer {
	private StreamTokenizer in;
	private Token current;

	private static Set<String> keywords;

	static {
		keywords = new HashSet<>();
		for (TokenType key : TokenType.keywords) {
			keywords.add(key.toString().toLowerCase());
		}
	}

	public Lexer(Reader input) throws ParserException {
		this.in = new StreamTokenizer(input);
		in.ordinaryChar('/');
		skip();
	}

	public boolean check(TokenType type) {
		return current.getType() == type;
	}

	public Token match(TokenType type) throws ParserException {
		if (check(type)) {
			return skip();
		} else {
			throw new ParserException("Expected " + type + ", but found " + current);
		}
	}

	public Token skip() throws ParserException {
		if (current != null && current.getType() == TokenType.EOF) {
			return current;
		}

		Token token = current;

		try {
			int next = in.nextToken();
			switch (next) {
			case StreamTokenizer.TT_EOF:
				current = new EOFToken();
				break;

			case StreamTokenizer.TT_WORD:
				if (keywords.contains(in.sval)) {
					current = new KeywordToken(in.sval);
				} else {
					current = new IdToken(in.sval);
				}
				break;

			case StreamTokenizer.TT_NUMBER:
				current = new NumToken(in.nval);
				break;

			default:
				current = new CharToken((char) next);
				break;
			}
		} catch (IOException e) {
			throw new ParserException(e.getMessage());
		}

		return token;
	}
}
