package csc426;

import java.io.IOException;

public class Lookahead {
	public Lookahead(Scanner scanner) {
		this.scanner = scanner;
		this.current = scanner.next();
	}

	public Token current() {
		return current;
	}

	public boolean check(TokenType type) {
		return current.type == type;
	}

	public Token match(TokenType type) {
		Token token = current;
		
		if (token.type == type) {
			current = scanner.next();
		} else {
			System.err.println("Error: Expected a " + type + ", found " + token);
			System.exit(1); // TODO improve this
		}
		return token;
	}

	public Token skip() {
		Token token = current;
		current = scanner.next();
		return token;
	}

	public void close() throws IOException {
		scanner.close();
	}

	private Scanner scanner;
	private Token current;
}
