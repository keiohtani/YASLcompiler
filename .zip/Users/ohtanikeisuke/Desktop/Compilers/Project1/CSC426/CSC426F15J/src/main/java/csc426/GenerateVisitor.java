package csc426;

import java.util.Iterator;

import csc426.AST.Block;
import csc426.AST.ConstDecl;
import csc426.AST.Expr;
import csc426.AST.Expr.BinOp;
import csc426.AST.Expr.False;
import csc426.AST.Expr.Id;
import csc426.AST.Expr.Num;
import csc426.AST.Expr.True;
import csc426.AST.Expr.UnOp;
import csc426.AST.Item;
import csc426.AST.Item.ExprItem;
import csc426.AST.Item.StringItem;
import csc426.AST.Param;
import csc426.AST.Param.Val;
import csc426.AST.Param.Var;
import csc426.AST.ProcDecl;
import csc426.AST.Program;
import csc426.AST.Stmt;
import csc426.AST.Stmt.Assign;
import csc426.AST.Stmt.Call;
import csc426.AST.Stmt.IfThen;
import csc426.AST.Stmt.IfThenElse;
import csc426.AST.Stmt.Print;
import csc426.AST.Stmt.Prompt;
import csc426.AST.Stmt.Prompt2;
import csc426.AST.Stmt.Sequence;
import csc426.AST.Stmt.While;
import csc426.AST.VarDecl;

public class GenerateVisitor implements ASTVisitor<Void> {
	protected Code code;
	protected SymbolTable<Info> table;
	private int offset;
	
	public GenerateVisitor(Code code) {
		this.code = code;
	}

	public String code() {
		return code.toString();
	}

	@Override
	public Void visit(Program program) {
		table = new SymbolTable<>();
		table.enter(program.name);
		program.block.accept(this);
		table.exit();
		code.halt();
		return null;
	}

	@Override
	public Void visit(Block block) {
		String s = code.newLabel();
		code.branch(s);
		for (ConstDecl cd : block.consts) {
			cd.accept(this);
		}
		offset = 0;
		for (VarDecl vd : block.vars) {
			vd.accept(this);
		}
		for (ProcDecl pd : block.procs) {
			pd.accept(this);
		}
		code.label(s);
		int n = block.vars.size();
		int level = table.level();
		code.enter(level);
		code.reserve(n);
		for (Stmt stmt : block.stmts) {
			stmt.accept(this);
		}
		code.drop(n);
		code.exit(level);
		return null;
	}

	@Override
	public Void visit(ConstDecl decl) {
		try {
			table.add(decl.id, new ConstInfo(decl.value));
		} catch (TableError e) {
			// this shouldn't happen
		}
		return null;
	}

	@Override
	public Void visit(VarDecl decl) {
		offset -= 1;
		try {
			table.add(decl.id, new VarInfo(table.level(), offset));
		} catch (TableError e) {
			// this shouldn't happen
		}
		return null;
	}

	@Override
	public Void visit(ProcDecl decl) {
		String s = code.newLabel();
		try {
			table.add(decl.id, new ProcInfo(s, decl.params));
		} catch (TableError e) {
			// this shouldn't happen
		}
		table.enter(decl.id);
		offset = 1;
		for (int i = decl.params.size() - 1; i >= 0; i--) {
			Param p = decl.params.get(i);
			p.accept(this);
		}
		code.label(s);
		decl.block.accept(this);
		code.ret();
		table.exit();
		return null;
	}

	@Override
	public Void visit(Val param) {
		offset += 1;
		try {
			table.add(param.id, new VarInfo(table.level(), offset));
		} catch (TableError e) {
			// this shouldn't happen
		}
		return null;
	}

	@Override
	public Void visit(Var param) {
		offset += 1;
		try {
			table.add(param.id, new RefInfo(table.level(), offset));
		} catch (TableError e) {
			// this shouldn't happen
		}
		return null;
	}

	@Override
	public Void visit(Assign stmt) {
		stmt.expr.accept(this);
		code.lvalue(stmt.id, table);
		code.store();
		return null;
	}

	@Override
	public Void visit(Call stmt) {
		try {
			ProcInfo info = (ProcInfo) table.lookup(stmt.id);
			Iterator<Expr> it = stmt.args.iterator();
			for (Param param : info.params) {
				Expr arg = it.next();
				if (param instanceof Param.Val) {
					arg.accept(this);
				} else {
					Id i = (Id) arg;
					code.lvalue(i.id, table);
				}
			}
			code.call(info.label);
			code.drop(info.params.size());
		} catch (TableError e) {
			// this shouldn't happen
		}
		return null;
	}

	@Override
	public Void visit(Sequence stmt) {
		for (Stmt s : stmt.body) {
			s.accept(this);
		}
		return null;
	}

	@Override
	public Void visit(IfThen stmt) {
		String y = code.newLabel();
		String n = code.newLabel();
		stmt.test.accept(new BooleanGenerateVisitor(this, y, n));
		code.label(y);
		stmt.trueClause.accept(this);
		code.label(n);
		return null;
	}

	@Override
	public Void visit(IfThenElse stmt) {
		String y = code.newLabel();
		String n = code.newLabel();
		String s = code.newLabel();
		stmt.test.accept(new BooleanGenerateVisitor(this, y, n));
		code.label(y);
		stmt.trueClause.accept(this);
		code.branch(s);
		code.label(n);
		stmt.falseClause.accept(this);
		code.label(s);
		return null;
	}

	@Override
	public Void visit(While stmt) {
		String y = code.newLabel();
		String n = code.newLabel();
		String s = code.newLabel();
		code.label(s);
		stmt.test.accept(new BooleanGenerateVisitor(this, y, n));
		code.label(y);
		stmt.body.accept(this);
		code.branch(s);
		code.label(n);
		return null;
	}

	@Override
	public Void visit(Prompt stmt) {
		code.print(stmt.message);
		code.readline();
		return null;
	}

	@Override
	public Void visit(Prompt2 stmt) {
		code.print(stmt.message + " ");
		code.readint();
		code.lvalue(stmt.id, table);
		code.store();
		return null;
	}

	@Override
	public Void visit(Print stmt) {
		for (Item it : stmt.items) {
			it.accept(this);
		}
		code.writeline();
		return null;
	}

	@Override
	public Void visit(ExprItem item) {
		item.expr.accept(this);
		code.writeint();
		return null;
	}

	@Override
	public Void visit(StringItem item) {
		code.print(item.message);
		return null;
	}

	@Override
	public Void visit(BinOp expr) {
		switch (expr.op) {
		case Plus:
			expr.left.accept(this);
			expr.right.accept(this);
			code.add();
			break;
		case Minus:
			expr.left.accept(this);
			expr.right.accept(this);
			code.sub();
			break;
		case Times:
			expr.left.accept(this);
			expr.right.accept(this);
			code.mul();
			break;
		case Div:
			expr.left.accept(this);
			expr.right.accept(this);
			code.div();
			break;
		case Mod:
			expr.left.accept(this);
			expr.right.accept(this);
			code.mod();
			break;
		default:
			bool2int(expr);
			break;
		}
		return null;
	}

	@Override
	public Void visit(UnOp expr) {
		switch (expr.op) {
		case Neg:
			code.constant(0);
			expr.expr.accept(this);
			code.sub();
			break;
		default:
			bool2int(expr);
			break;
		}
		return null;
	}

	@Override
	public Void visit(Num expr) {
		code.constant(expr.value);
		return null;
	}

	@Override
	public Void visit(Id expr) {
		Info info;
		try {
			info = table.lookup(expr.id);
			if (info instanceof ConstInfo) {
				ConstInfo ci = (ConstInfo) info;
				code.constant(ci.value);
			} else {
				code.lvalue(expr.id, table);
				code.load();
			}
		} catch (TableError e) {
			// this shouldn't happen
		}
		return null;
	}

	@Override
	public Void visit(True expr) {
		code.constant(1);
		return null;
	}

	@Override
	public Void visit(False expr) {
		code.constant(0);
		return null;
	}

	class BooleanGenerateVisitor extends GenerateVisitor {
		public BooleanGenerateVisitor(GenerateVisitor parent, String y, String n) {
			super(parent.code);
			this.table = parent.table;
			this.parent = parent;
			this.y = y;
			this.n = n;
		}

		@Override
		public Void visit(BinOp expr) {
			switch (expr.op) {
			case And: {
				String s = code.newLabel();
				expr.left.accept(new BooleanGenerateVisitor(parent, s, n));
				code.label(s);
				expr.right.accept(this);
				break;
			}
			case Or: {
				String s = code.newLabel();
				expr.left.accept(new BooleanGenerateVisitor(parent, y, s));
				code.label(s);
				expr.right.accept(this);
				break;
			}
			case EQ:
				expr.left.accept(parent);
				expr.right.accept(parent);
				code.sub();
				code.branchzero(y);
				code.branch(n);
				break;
			case NE:
				expr.left.accept(parent);
				expr.right.accept(parent);
				code.sub();
				code.branchzero(n);
				code.branch(y);
				break;
			case LT:
				expr.left.accept(parent);
				expr.right.accept(parent);
				code.sub();
				code.branchneg(y);
				code.branch(n);
				break;
			case GE:
				expr.left.accept(parent);
				expr.right.accept(parent);
				code.sub();
				code.branchneg(n);
				code.branch(y);
				break;
			case GT:
				expr.right.accept(parent);
				expr.left.accept(parent);
				code.sub();
				code.branchneg(y);
				code.branch(n);
				break;
			case LE:
				expr.right.accept(parent);
				expr.left.accept(parent);
				code.sub();
				code.branchneg(n);
				code.branch(y);
				break;
			default:
				// this shouldn't happen
			}
			return null;
		}

		@Override
		public Void visit(UnOp expr) {
			switch (expr.op) {
			case Not:
				expr.expr.accept(new BooleanGenerateVisitor(parent, n, y));
				break;
			default:
				// this shouldn't happen
			}
			return null;
		}

		@Override
		public Void visit(Id expr) {
			code.lvalue(expr.id, table);
			code.load();
			code.branchzero(n);
			code.branch(y);
			return null;
		}

		@Override
		public Void visit(True expr) {
			code.branch(y);
			return null;
		}

		@Override
		public Void visit(False expr) {
			code.branch(n);
			return null;
		}

		private GenerateVisitor parent;
		private String y, n;
	}

	private void bool2int(Expr expr) {
		String y = code.newLabel();
		String n = code.newLabel();
		String s = code.newLabel();
		expr.accept(new BooleanGenerateVisitor(this, y, n));
		code.label(y);
		code.constant(1);
		code.branch(s);
		code.label(n);
		code.constant(0);
		code.label(s);
	}
}
