package csc426.ast;

public class AssignNumStmt implements Stmt {
	private String lhs;
	private double num;

	public AssignNumStmt(String lhs, double num) {
		this.lhs = lhs;
		this.num = num;
	}

	public void accept(Visitor v) {
		v.assignNum(lhs, num);
	}
}
