package edu.depauw.csc426

import scala.util.parsing.combinator.token.Tokens

/**
 * @author bhoward
 */
trait YASLTokens extends Tokens {
  case class ID(chars: String) extends Token

  case class NUM(chars: String) extends Token

  case object PROGRAM extends Token { val chars: String = "program" }
  case object CONST extends Token { val chars: String = "const" }
  case object BEGIN extends Token { val chars: String = "begin" }
  case object PRINT extends Token { val chars: String = "print" }
  case object END extends Token { val chars: String = "end" }

  case object DIV extends Token { val chars: String = "div" }
  case object MOD extends Token { val chars: String = "mod" }

  case object PLUS extends Token { val chars: String = "+" }
  case object MINUS extends Token { val chars: String = "-" }
  case object STAR extends Token { val chars: String = "*" }
  case object ASSIGN extends Token { val chars: String = "=" }

  case object SEMI extends Token { val chars: String = ";" }
  case object PERIOD extends Token { val chars: String = "." }
}