package csc426

import java.io.Reader
import scala.annotation.tailrec


/**
 * A Lexical Analyzer for a subset of YASL. Uses a (Mealy) state machine to
 * extract the next available token from the input each time next() is called.
 * Input comes from a Reader, which will generally be a BufferedReader wrapped
 * around a FileReader or InputStreamReader (though for testing it may also be
 * simply a StringReader).
 * 
 * @author bhoward
 */
class Scanner(in: Reader) {
  val source = new Source(in)
  
  /**
   * Extract the next available token. When the input is exhausted, it will
   * return an EOF token on all future calls.
   * 
   * @return the next Token object
   */
  def next(): Token = {
    @tailrec
    def run(state: State): Token = {
      val newState = state.step(source)
      if (newState.done) {
        newState.token
      } else {
        source.advance()
        run(newState)
      }
    }
    
    run(State.InitialState)
  }
  
  /**
   * Close the underlying Reader.
   */
  def close(): Unit = source.close()
}