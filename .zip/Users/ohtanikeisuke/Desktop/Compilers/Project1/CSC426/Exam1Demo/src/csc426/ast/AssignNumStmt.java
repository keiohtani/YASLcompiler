package csc426.ast;

import csc426.NumValue;
import csc426.SymbolTable;
import csc426.Value;

public class AssignNumStmt implements Stmt {
	private String lhs;
	private double num;

	public AssignNumStmt(String lhs, double num) {
		this.lhs = lhs;
		this.num = num;
	}

	public String render(String indent) {
		return indent + "ASSIGN_NUM " + lhs + " = " + num + "\n";
	}

	public void interpret(SymbolTable<Value> table) {
		table.bind(lhs, new NumValue(num));
	}
}
