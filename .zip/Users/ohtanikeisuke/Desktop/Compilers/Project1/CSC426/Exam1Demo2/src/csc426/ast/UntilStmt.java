package csc426.ast;

public class UntilStmt implements Stmt {
	private String test;
	private Stmt body;

	public UntilStmt(String test, Stmt body) {
		this.test = test;
		this.body = body;
	}

	public void accept(Visitor v) {
		v.until(test, body);
	}
}
