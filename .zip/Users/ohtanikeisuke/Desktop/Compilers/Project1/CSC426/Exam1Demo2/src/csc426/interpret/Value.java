package csc426.interpret;

import csc426.ast.Stmt;

public interface Value {
	/**
	 * Extract a number from this value, or throw an exception if it is not a
	 * NumValue.
	 * 
	 * @return the number from this value
	 * @throws InterpreterException
	 */
	public double asDouble() throws InterpreterException;

	/**
	 * Extract a statement from this value, or throw an exception if it is not a
	 * StmtValue.
	 * 
	 * @return the statement object from this value
	 * @throws InterpreterException 
	 */
	public Stmt asStatement() throws InterpreterException;
}
