package edu.depauw.csc426;

import static org.junit.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

import org.junit.Test;

public class ScannerTest3 {

	/**
	 * A test of identifiers.
	 * 
	 * test5.in is
-------
// Identifiers
aaaaaaaaaaaaaaaaaaaa aaaaaaaaaaaaaaaaaaab aaaaaaaaaaaaaaaaaxyz
a1234567890123456xyz
AaBbCcDdEeFfGgHhIi
JjKkLlMmNnOoPpQq
RrSsTtUuVvWwXx
YyZz0123456789
a A a1 A1
a+b-c*d=e;f.g//
 x  y   z
1a2b3c 4d5e6f 7G8H9I 0J-K=L
-------
	 * @throws IOException 
	 */
	@Test
	public void test5() throws IOException {
		Reader in = new BufferedReader(new FileReader("test5.in"));
		Scanner scanner = new Scanner(in);

		Token t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(2, t.line);
		assertEquals(1, t.column);
		assertEquals("aaaaaaaaaaaaaaaaaaaa", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(2, t.line);
		assertEquals(22, t.column);
		assertEquals("aaaaaaaaaaaaaaaaaaab", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(2, t.line);
		assertEquals(43, t.column);
		assertEquals("aaaaaaaaaaaaaaaaaxyz", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(3, t.line);
		assertEquals(1, t.column);
		assertEquals("a1234567890123456xyz", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(4, t.line);
		assertEquals(1, t.column);
		assertEquals("AaBbCcDdEeFfGgHhIi", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(5, t.line);
		assertEquals(1, t.column);
		assertEquals("JjKkLlMmNnOoPpQq", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(6, t.line);
		assertEquals(1, t.column);
		assertEquals("RrSsTtUuVvWwXx", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(7, t.line);
		assertEquals(1, t.column);
		assertEquals("YyZz0123456789", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(8, t.line);
		assertEquals(1, t.column);
		assertEquals("a", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(8, t.line);
		assertEquals(3, t.column);
		assertEquals("A", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(8, t.line);
		assertEquals(5, t.column);
		assertEquals("a1", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(8, t.line);
		assertEquals(8, t.column);
		assertEquals("A1", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(9, t.line);
		assertEquals(1, t.column);
		assertEquals("a", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.PLUS, t.type);
		assertEquals(9, t.line);
		assertEquals(2, t.column);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(9, t.line);
		assertEquals(3, t.column);
		assertEquals("b", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.MINUS, t.type);
		assertEquals(9, t.line);
		assertEquals(4, t.column);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(9, t.line);
		assertEquals(5, t.column);
		assertEquals("c", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.STAR, t.type);
		assertEquals(9, t.line);
		assertEquals(6, t.column);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(9, t.line);
		assertEquals(7, t.column);
		assertEquals("d", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ASSIGN, t.type);
		assertEquals(9, t.line);
		assertEquals(8, t.column);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(9, t.line);
		assertEquals(9, t.column);
		assertEquals("e", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.SEMI, t.type);
		assertEquals(9, t.line);
		assertEquals(10, t.column);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(9, t.line);
		assertEquals(11, t.column);
		assertEquals("f", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.PERIOD, t.type);
		assertEquals(9, t.line);
		assertEquals(12, t.column);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(9, t.line);
		assertEquals(13, t.column);
		assertEquals("g", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(10, t.line);
		assertEquals(2, t.column);
		assertEquals("x", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(10, t.line);
		assertEquals(5, t.column);
		assertEquals("y", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(10, t.line);
		assertEquals(9, t.column);
		assertEquals("z", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(11, t.line);
		assertEquals(1, t.column);
		assertEquals("1", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(11, t.line);
		assertEquals(2, t.column);
		assertEquals("a2b3c", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(11, t.line);
		assertEquals(8, t.column);
		assertEquals("4", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(11, t.line);
		assertEquals(9, t.column);
		assertEquals("d5e6f", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(11, t.line);
		assertEquals(15, t.column);
		assertEquals("7", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(11, t.line);
		assertEquals(16, t.column);
		assertEquals("G8H9I", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(11, t.line);
		assertEquals(22, t.column);
		assertEquals("0", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(11, t.line);
		assertEquals(23, t.column);
		assertEquals("J", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.MINUS, t.type);
		assertEquals(11, t.line);
		assertEquals(24, t.column);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(11, t.line);
		assertEquals(25, t.column);
		assertEquals("K", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ASSIGN, t.type);
		assertEquals(11, t.line);
		assertEquals(26, t.column);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(11, t.line);
		assertEquals(27, t.column);
		assertEquals("L", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.EOF, t.type);
		assertEquals(12, t.line);
		assertEquals(1, t.column);
	}

	/**
	 * A test of whitespace.
	 * 
	 * test6.in is
-------
// Whitespace

 
  
a
 b
  c
	d	e
a{}b{ }c{	}d//e



     
//    }
{ // }
{{}{
// multiline brace comment
}

-------
	 * @throws IOException 
	 */
	@Test
	public void test6() throws IOException {
		Reader in = new BufferedReader(new FileReader("test6.in"));
		Scanner scanner = new Scanner(in);

		Token t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(5, t.line);
		assertEquals(1, t.column);
		assertEquals("a", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(6, t.line);
		assertEquals(2, t.column);
		assertEquals("b", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(7, t.line);
		assertEquals(3, t.column);
		assertEquals("c", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(8, t.line);
		assertEquals(2, t.column);
		assertEquals("d", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(8, t.line);
		assertEquals(4, t.column);
		assertEquals("e", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(9, t.line);
		assertEquals(1, t.column);
		assertEquals("a", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(9, t.line);
		assertEquals(4, t.column);
		assertEquals("b", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(9, t.line);
		assertEquals(8, t.column);
		assertEquals("c", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(9, t.line);
		assertEquals(12, t.column);
		assertEquals("d", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.EOF, t.type);
		assertEquals(20, t.line);
		assertEquals(1, t.column);
	}

	/**
	 * A test of keywords.
	 * 
	 * test7.in is
-------
// Keywords
program const begin print end div mod
program+const-begin*print=end;div.mod//
program123 123program
1+2div 3mod 4mod5
beginend
div{}mod
const	print
-------
	 * @throws IOException 
	 */
	@Test
	public void test7() throws IOException {
		Reader in = new BufferedReader(new FileReader("test7.in"));
		Scanner scanner = new Scanner(in);

		Token t = scanner.next();
		assertEquals(TokenType.PROGRAM, t.type);
		assertEquals(2, t.line);
		assertEquals(1, t.column);

		t = scanner.next();
		assertEquals(TokenType.CONST, t.type);
		assertEquals(2, t.line);
		assertEquals(9, t.column);

		t = scanner.next();
		assertEquals(TokenType.BEGIN, t.type);
		assertEquals(2, t.line);
		assertEquals(15, t.column);

		t = scanner.next();
		assertEquals(TokenType.PRINT, t.type);
		assertEquals(2, t.line);
		assertEquals(21, t.column);

		t = scanner.next();
		assertEquals(TokenType.END, t.type);
		assertEquals(2, t.line);
		assertEquals(27, t.column);

		t = scanner.next();
		assertEquals(TokenType.DIV, t.type);
		assertEquals(2, t.line);
		assertEquals(31, t.column);

		t = scanner.next();
		assertEquals(TokenType.MOD, t.type);
		assertEquals(2, t.line);
		assertEquals(35, t.column);

		t = scanner.next();
		assertEquals(TokenType.PROGRAM, t.type);
		assertEquals(3, t.line);
		assertEquals(1, t.column);

		t = scanner.next();
		assertEquals(TokenType.PLUS, t.type);
		assertEquals(3, t.line);
		assertEquals(8, t.column);

		t = scanner.next();
		assertEquals(TokenType.CONST, t.type);
		assertEquals(3, t.line);
		assertEquals(9, t.column);

		t = scanner.next();
		assertEquals(TokenType.MINUS, t.type);
		assertEquals(3, t.line);
		assertEquals(14, t.column);

		t = scanner.next();
		assertEquals(TokenType.BEGIN, t.type);
		assertEquals(3, t.line);
		assertEquals(15, t.column);

		t = scanner.next();
		assertEquals(TokenType.STAR, t.type);
		assertEquals(3, t.line);
		assertEquals(20, t.column);

		t = scanner.next();
		assertEquals(TokenType.PRINT, t.type);
		assertEquals(3, t.line);
		assertEquals(21, t.column);

		t = scanner.next();
		assertEquals(TokenType.ASSIGN, t.type);
		assertEquals(3, t.line);
		assertEquals(26, t.column);

		t = scanner.next();
		assertEquals(TokenType.END, t.type);
		assertEquals(3, t.line);
		assertEquals(27, t.column);

		t = scanner.next();
		assertEquals(TokenType.SEMI, t.type);
		assertEquals(3, t.line);
		assertEquals(30, t.column);

		t = scanner.next();
		assertEquals(TokenType.DIV, t.type);
		assertEquals(3, t.line);
		assertEquals(31, t.column);

		t = scanner.next();
		assertEquals(TokenType.PERIOD, t.type);
		assertEquals(3, t.line);
		assertEquals(34, t.column);

		t = scanner.next();
		assertEquals(TokenType.MOD, t.type);
		assertEquals(3, t.line);
		assertEquals(35, t.column);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(4, t.line);
		assertEquals(1, t.column);
		assertEquals("program123", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(4, t.line);
		assertEquals(12, t.column);
		assertEquals("123", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.PROGRAM, t.type);
		assertEquals(4, t.line);
		assertEquals(15, t.column);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(5, t.line);
		assertEquals(1, t.column);
		assertEquals("1", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.PLUS, t.type);
		assertEquals(5, t.line);
		assertEquals(2, t.column);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(5, t.line);
		assertEquals(3, t.column);
		assertEquals("2", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.DIV, t.type);
		assertEquals(5, t.line);
		assertEquals(4, t.column);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(5, t.line);
		assertEquals(8, t.column);
		assertEquals("3", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.MOD, t.type);
		assertEquals(5, t.line);
		assertEquals(9, t.column);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(5, t.line);
		assertEquals(13, t.column);
		assertEquals("4", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(5, t.line);
		assertEquals(14, t.column);
		assertEquals("mod5", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(6, t.line);
		assertEquals(1, t.column);
		assertEquals("beginend", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.DIV, t.type);
		assertEquals(7, t.line);
		assertEquals(1, t.column);

		t = scanner.next();
		assertEquals(TokenType.MOD, t.type);
		assertEquals(7, t.line);
		assertEquals(6, t.column);

		t = scanner.next();
		assertEquals(TokenType.CONST, t.type);
		assertEquals(8, t.line);
		assertEquals(1, t.column);

		t = scanner.next();
		assertEquals(TokenType.PRINT, t.type);
		assertEquals(8, t.line);
		assertEquals(7, t.column);

		t = scanner.next();
		assertEquals(TokenType.DIV, t.type);
		assertEquals(9, t.line);
		assertEquals(1, t.column);

		t = scanner.next();
		assertEquals(TokenType.PLUS, t.type);
		assertEquals(9, t.line);
		assertEquals(4, t.column);

		t = scanner.next();
		assertEquals(TokenType.MINUS, t.type);
		assertEquals(9, t.line);
		assertEquals(5, t.column);

		t = scanner.next();
		assertEquals(TokenType.STAR, t.type);
		assertEquals(9, t.line);
		assertEquals(6, t.column);

		t = scanner.next();
		assertEquals(TokenType.ASSIGN, t.type);
		assertEquals(9, t.line);
		assertEquals(7, t.column);

		t = scanner.next();
		assertEquals(TokenType.SEMI, t.type);
		assertEquals(9, t.line);
		assertEquals(8, t.column);

		t = scanner.next();
		assertEquals(TokenType.PERIOD, t.type);
		assertEquals(9, t.line);
		assertEquals(9, t.column);

		t = scanner.next();
		assertEquals(TokenType.MOD, t.type);
		assertEquals(9, t.line);
		assertEquals(10, t.column);

		t = scanner.next();
		assertEquals(TokenType.MOD, t.type);
		assertEquals(10, t.line);
		assertEquals(1, t.column);

		t = scanner.next();
		assertEquals(TokenType.PERIOD, t.type);
		assertEquals(10, t.line);
		assertEquals(4, t.column);

		t = scanner.next();
		assertEquals(TokenType.SEMI, t.type);
		assertEquals(10, t.line);
		assertEquals(5, t.column);

		t = scanner.next();
		assertEquals(TokenType.ASSIGN, t.type);
		assertEquals(10, t.line);
		assertEquals(6, t.column);

		t = scanner.next();
		assertEquals(TokenType.STAR, t.type);
		assertEquals(10, t.line);
		assertEquals(7, t.column);

		t = scanner.next();
		assertEquals(TokenType.MINUS, t.type);
		assertEquals(10, t.line);
		assertEquals(8, t.column);

		t = scanner.next();
		assertEquals(TokenType.PLUS, t.type);
		assertEquals(10, t.line);
		assertEquals(9, t.column);

		t = scanner.next();
		assertEquals(TokenType.DIV, t.type);
		assertEquals(10, t.line);
		assertEquals(10, t.column);

		t = scanner.next();
		assertEquals(TokenType.EOF, t.type);
		assertEquals(11, t.line);
		assertEquals(1, t.column);
	}
	
	/**
	 * A test of numbers.
	 * 
	 * test8.in is
-------
// Numbers
1 23 456 7890 1234567890
12345678901234567890// Too long?
 0123	456{}789
0000000000000
-------
	 * @throws IOException 
	 */
	@Test
	public void test8() throws IOException {
		Reader in = new BufferedReader(new FileReader("test8.in"));
		Scanner scanner = new Scanner(in);

		Token t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(2, t.line);
		assertEquals(1, t.column);
		assertEquals("1", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(2, t.line);
		assertEquals(3, t.column);
		assertEquals("23", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(2, t.line);
		assertEquals(6, t.column);
		assertEquals("456", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(2, t.line);
		assertEquals(10, t.column);
		assertEquals("7890", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(2, t.line);
		assertEquals(15, t.column);
		assertEquals("1234567890", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(3, t.line);
		assertEquals(1, t.column);
		assertEquals("12345678901234567890", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(4, t.line);
		assertEquals(2, t.column);
		assertEquals("0", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(4, t.line);
		assertEquals(3, t.column);
		assertEquals("123", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(4, t.line);
		assertEquals(7, t.column);
		assertEquals("456", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(4, t.line);
		assertEquals(12, t.column);
		assertEquals("789", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(5, t.line);
		assertEquals(1, t.column);
		assertEquals("0", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(5, t.line);
		assertEquals(2, t.column);
		assertEquals("0", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(5, t.line);
		assertEquals(3, t.column);
		assertEquals("0", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(5, t.line);
		assertEquals(4, t.column);
		assertEquals("0", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(5, t.line);
		assertEquals(5, t.column);
		assertEquals("0", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(5, t.line);
		assertEquals(6, t.column);
		assertEquals("0", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(5, t.line);
		assertEquals(7, t.column);
		assertEquals("0", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(5, t.line);
		assertEquals(8, t.column);
		assertEquals("0", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(5, t.line);
		assertEquals(9, t.column);
		assertEquals("0", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(5, t.line);
		assertEquals(10, t.column);
		assertEquals("0", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(5, t.line);
		assertEquals(11, t.column);
		assertEquals("0", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(5, t.line);
		assertEquals(12, t.column);
		assertEquals("0", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(5, t.line);
		assertEquals(13, t.column);
		assertEquals("0", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.EOF, t.type);
		assertEquals(6, t.line);
		assertEquals(1, t.column);
	}
}
