package edu.depauw.csc426;

import static org.junit.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

import org.junit.Test;

public class ScannerTest1 {
	/**
	 * A simple test with no whitespace
	 * 
	 * test1.in is
-------
12+3-456*7890;
-------
	 * @throws IOException 
	 */
	@Test
	public void test1() throws IOException {
		Reader in = new BufferedReader(new FileReader("test1.in"));
		Scanner scanner = new Scanner(in);

		Token t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(1, t.line);
		assertEquals(1, t.column);
		assertEquals("12", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.PLUS, t.type);
		assertEquals(1, t.line);
		assertEquals(3, t.column);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(1, t.line);
		assertEquals(4, t.column);
		assertEquals("3", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.MINUS, t.type);
		assertEquals(1, t.line);
		assertEquals(5, t.column);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(1, t.line);
		assertEquals(6, t.column);
		assertEquals("456", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.STAR, t.type);
		assertEquals(1, t.line);
		assertEquals(9, t.column);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(1, t.line);
		assertEquals(10, t.column);
		assertEquals("7890", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.SEMI, t.type);
		assertEquals(1, t.line);
		assertEquals(14, t.column);

		t = scanner.next();
		assertEquals(TokenType.EOF, t.type);
		assertEquals(1, t.line);
		assertEquals(15, t.column);
	}

	/**
	 * A similar test with whitespace and comments
	 * 
	 * test2.in is
-------
12 +	3
   -
// This is a comment
456// This is another comment
  *  7890
;
-------
	 * @throws IOException 
	 */
	@Test
	public void test2() throws IOException {
		Reader in = new BufferedReader(new FileReader("test2.in"));
		Scanner scanner = new Scanner(in);

		Token t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(1, t.line);
		assertEquals(1, t.column);
		assertEquals("12", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.PLUS, t.type);
		assertEquals(1, t.line);
		assertEquals(4, t.column);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(1, t.line);
		assertEquals(6, t.column);
		assertEquals("3", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.MINUS, t.type);
		assertEquals(2, t.line);
		assertEquals(4, t.column);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(4, t.line);
		assertEquals(1, t.column);
		assertEquals("456", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.STAR, t.type);
		assertEquals(5, t.line);
		assertEquals(3, t.column);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(5, t.line);
		assertEquals(6, t.column);
		assertEquals("7890", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.SEMI, t.type);
		assertEquals(6, t.line);
		assertEquals(1, t.column);

		t = scanner.next();
		assertEquals(TokenType.EOF, t.type);
		assertEquals(7, t.line);
		assertEquals(1, t.column);
	}
}
