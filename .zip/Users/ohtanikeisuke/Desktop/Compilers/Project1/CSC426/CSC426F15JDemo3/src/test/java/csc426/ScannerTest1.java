package csc426;

import static org.junit.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

import org.junit.Test;

import csc426.parser.ErrorLog;
import csc426.parser.Lexer;
import csc426.parser.Position;
import csc426.parser.Token;
import csc426.parser.TokenType;

public class ScannerTest1 {
	/**
	 * A simple test with no whitespace
	 * 
	 * test1.in is
-------
12+3-456*7890;
-------
	 * @throws IOException 
	 */
	@Test
	public void test1() throws IOException {
		Reader in = new BufferedReader(new FileReader("resource/project1/test1.in"));
		Lexer scanner = new Lexer(in, new ErrorLog());

		Token t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(1, 1), t.position);
		assertEquals("12", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.PLUS, t.type);
		assertEquals(new Position(1, 3), t.position);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(1, 4), t.position);
		assertEquals("3", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.MINUS, t.type);
		assertEquals(new Position(1, 5), t.position);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(1, 6), t.position);
		assertEquals("456", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.STAR, t.type);
		assertEquals(new Position(1, 9), t.position);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(1, 10), t.position);
		assertEquals("7890", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.SEMI, t.type);
		assertEquals(new Position(1, 14), t.position);

		t = scanner.next();
		assertEquals(TokenType.EOF, t.type);
		assertEquals(new Position(1, 15), t.position);
	}

	/**
	 * A similar test with whitespace and comments
	 * 
	 * test2.in is
-------
12 +	3
   -
// This is a comment
456// This is another comment
  *  7890
;
-------
	 * @throws IOException 
	 */
	@Test
	public void test2() throws IOException {
		Reader in = new BufferedReader(new FileReader("resource/project1/test2.in"));
		Lexer scanner = new Lexer(in, new ErrorLog());

		Token t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(1, 1), t.position);
		assertEquals("12", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.PLUS, t.type);
		assertEquals(new Position(1, 4), t.position);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(1, 6), t.position);
		assertEquals("3", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.MINUS, t.type);
		assertEquals(new Position(2, 4), t.position);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(4, 1), t.position);
		assertEquals("456", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.STAR, t.type);
		assertEquals(new Position(5, 3), t.position);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(5, 6), t.position);
		assertEquals("7890", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.SEMI, t.type);
		assertEquals(new Position(6, 1), t.position);

		t = scanner.next();
		assertEquals(TokenType.EOF, t.type);
		assertEquals(new Position(7, 1), t.position);
	}
}
