package edu.depauw.csc426

/**
 * @author bhoward
 */
sealed trait Instruction {
  def toPep9: List[String]
}

object Instruction {
  val runtime: String =
    """display_: .BLOCK  20
      |mult_:    LDWX    16,i
      |          LDWA    0,i
      |          STWA    -2,s
      |M_0:      LDWA    -2,s
      |          ASRA
      |          STWA    -2,s
      |          LDWA    2,s
      |          RORA
      |          STWA    2,s
      |          BRC     M_2
      |M_1:      SUBX    1,i
      |          BRNE    M_0
      |          BR      M_4
      |M_2:      LDWA    -2,s
      |          SUBA    4,s
      |          STWA    -2,s
      |M_3:      SUBX    1,i
      |          BREQ    M_4
      |          LDWA    -2,s
      |          ASRA
      |          STWA    -2,s
      |          LDWA    2,s
      |          RORA
      |          STWA    2,s
      |          BRC     M_3
      |          LDWA    -2,s
      |          ADDA    4,s
      |          STWA    -2,s
      |          BR      M_1
      |M_4:      LDWA    -2,s
      |          ASRA
      |          LDWX    2,s
      |          RORX
      |          STWX    4,s
      |          STWA    2,s
      |          RET
      |div_:     LDWX    0,i
      |          LDWA    4,s
      |          BRGE    M_5
      |          NEGA
      |          STWA    4,s
      |          ORX     3,i
      |M_5:      LDWA    2,s
      |          BRGE    M_6
      |          NEGA
      |          STWA    2,s
      |          ADDX    2,i
      |M_6:      STBX    -3,s
      |          LDWA    0,i
      |          STWA    -2,s
      |          LDWX    16,i
      |M_7:      LDWA    4,s
      |          ASLA
      |          STWA    4,s
      |          LDWA    -2,s
      |          ROLA
      |          BRC     M_8
      |          SUBA    2,s
      |          BR      M_9
      |M_8:      ADDA    2,s
      |M_9:      STWA    -2,s
      |          BRLT    M_10
      |          LDWA    4,s
      |          ORA     1,i
      |          STWA    4,s
      |M_10:     SUBX    1,i
      |          BRNE    M_7
      |          LDWA    -2,s
      |          BRGE    M_11
      |          ADDA    2,s
      |M_11:     LDBX    -3,s
      |          ANDX    1,i
      |          BREQ    M_12
      |          NEGA
      |M_12:     STWA    2,s
      |          LDBX    -3,s
      |          ANDX    2,i
      |          BREQ    M_13
      |          LDWA    4,s
      |          NEGA
      |          STWA    4,s
      |M_13:     RET
      |          .END""".stripMargin
}

case class Label(name: String) extends Instruction {
  def toPep9 = List(
    s"$name: NOP0")
}
case class BranchZero(name: String) extends Instruction {
  def toPep9 = List(
    "ADDSP 2, i",
    "LDWA -2, s",
    s"BREQ $name")
}
case class BranchNeg(name: String) extends Instruction {
  def toPep9 = List(
    "ADDSP 2, i",
    "LDWA -2, s",
    s"BRLT $name")
}
case class Branch(name: String) extends Instruction {
  def toPep9 = List(
    s"BR $name")
}
case class Call(name: String) extends Instruction {
  def toPep9 = List(
    s"CALL $name")
}
case object Return extends Instruction {
  def toPep9 = List(
    "RET")
}
case class Reserve(n: Int) extends Instruction {
  def toPep9 = List(
    s"SUBSP ${2 * n}, i")
}
case class Drop(n: Int) extends Instruction {
  def toPep9 = List(
    s"ADDSP ${2 * n}, i")
}
case class Enter(level: Int) extends Instruction {
  def toPep9 = List(
    s"LDWX ${2 * level}, i",
    "LDWA display_, x",
    "SUBSP 2, i",
    "STWA 0, s",
    "MOVSPA",
    "STWA display_, x")
}
case class Exit(level: Int) extends Instruction {
  def toPep9 = List(
    "LDWA 0, s",
    "ADDSP 2, i",
    s"LDWX ${2 * level}, i",
    "STWA display_, x")
}
case class Address(level: Int, offset: Int) extends Instruction {
  def toPep9 = List(
    s"LDWX ${2 * level}, i",
    "LDWA display_, x",
    s"ADDA ${2 * offset}, i",
    "SUBSP 2, i",
    "STWA 0, s")
}
case object Load extends Instruction {
  def toPep9 = List(
    "LDWA 0, sf",
    "STWA 0, s")
}
case object Store extends Instruction {
  def toPep9 = List(
    "LDWA 2, s",
    "STWA 0, sf",
    "ADDSP 4, i")
}
case class Constant(n: Int) extends Instruction {
  def toPep9 = List(
    s"LDWA $n, i",
    "SUBSP 2, i",
    "STWA 0, s")
}
case object Add extends Instruction {
  def toPep9 = List(
    "LDWA 2, s",
    "ADDA 0, s",
    "ADDSP 2, i",
    "STWA 0, s")
}
case object Sub extends Instruction {
  def toPep9 = List(
    "LDWA 2, s",
    "SUBA 0, s",
    "ADDSP 2, i",
    "STWA 0, s")
}
case object Mul extends Instruction {
  def toPep9 = List(
    "CALL mult_",
    "ADDSP 2, i")
}
case object Div extends Instruction {
  def toPep9 = List(
    "CALL div_",
    "ADDSP 2, i")
}
case object Mod extends Instruction {
  def toPep9 = List(
    "CALL div_",
    "LDWA 0, s",
    "STWA 2, s",
    "ADDSP 2, i")
}
case object ReadLine extends Instruction {
  def toPep9 = List(
    "LDBA charIn, d",
    "STBA -1, s")
}
case object ReadInt extends Instruction {
  def toPep9 = List(
    "SUBSP 2, i",
    "DECI 0, s")
}
case object WriteInt extends Instruction {
  def toPep9 = List(
    "DECO 0, s",
    "ADDSP 2, i")
}
case object WriteChar extends Instruction {
  def toPep9 = List(
    "LDBA 1, s",
    "STBA charOut, d",
    "ADDSP 2, i")
}
case object WriteLine extends Instruction {
  def toPep9 = List(
    "LDBA 10, i",
    "STBA charOut, d")
}
case object Halt extends Instruction {
  def toPep9 = List(
    "STOP")
}

// This is only used in optimization:
case object Dup extends Instruction {
  def toPep9 = List(
    "LDWA 0, s",
    "SUBSP 2, i",
    "STWA 0, s")
}