package csc426;

import java.util.ArrayList;
import java.util.List;

import csc426.AST.*;
import csc426.AST.Expr.*;
import csc426.AST.Item.*;
import csc426.AST.Param.*;
import csc426.AST.Stmt.*;

public class TypeCheckVisitor implements ASTVisitor<TypeValue> {
	private SymbolTable<TypeValue> table;

	@Override
	public TypeValue visit(Program program) {
		table = new SymbolTable<TypeValue>();
		table.enter(program.name);
		program.block.accept(this);
		table.exit();
		return null;
	}

	@Override
	public TypeValue visit(Block block) {
		for (ConstDecl cd : block.consts) {
			cd.accept(this);
		}
		for (VarDecl vd : block.vars) {
			vd.accept(this);
		}
		for (ProcDecl pd : block.procs) {
			try {
				table.add(pd.id, new TypeValue.ProcVal(pd.params));
			} catch (TableError e) {
				throw new TypeCheckError(e.getMessage(), pd);
			}
		}
		for (ProcDecl pd : block.procs) {
			pd.accept(this);
		}
		for (Stmt s : block.stmts) {
			s.accept(this);
		}
		return null;
	}

	@Override
	public TypeValue visit(ConstDecl decl) {
		try {
			table.add(decl.id, new TypeValue.IntVal());
		} catch (TableError e) {
			throw new TypeCheckError(e.getMessage(), decl);
		}
		return null;
	}

	@Override
	public TypeValue visit(VarDecl decl) {
		try {
			switch (decl.type) {
			case Int:
				table.add(decl.id, new TypeValue.IntVar());
				break;
			case Bool:
				table.add(decl.id, new TypeValue.BoolVar());
				break;
			}
		} catch (TableError e) {
			throw new TypeCheckError(e.getMessage(), decl);
		}
		return null;
	}

	@Override
	public TypeValue visit(ProcDecl decl) {
		table.enter(decl.id);
		for (Param param : decl.params) {
			try {
				switch (param.type) {
				case Int:
					table.add(param.id, new TypeValue.IntVar());
					break;
				case Bool:
					table.add(param.id, new TypeValue.BoolVar());
					break;
				}
			} catch (TableError e) {
				throw new TypeCheckError(e.getMessage(), param);
			}
		}
		decl.block.accept(this);
		table.exit();
		return null;
	}

	@Override
	public TypeValue visit(Val param) {
		// not used
		return null;
	}

	@Override
	public TypeValue visit(Var param) {
		// not used
		return null;
	}

	@Override
	public TypeValue visit(Assign stmt) {
		try {
			TypeValue lhs = table.lookup(stmt.id);
			TypeValue rhs = stmt.expr.accept(this);
			if (!lhs.isVar()) {
				throw new TypeCheckError("Left-hand side not a variable", stmt);
			}
			if (lhs.type() != rhs.type()) {
				throw new TypeCheckError("Type mismatch", stmt);
			}
		} catch (TableError e) {
			throw new TypeCheckError(e.getMessage(), stmt);
		} catch (ValueError e) {
			throw new TypeCheckError(e.getMessage(), stmt);
		}
		return null;
	}

	@Override
	public TypeValue visit(Call stmt) {
		try {
			TypeValue proc = table.lookup(stmt.id);
			List<TypeValue> args = new ArrayList<>();
			for (Expr arg : stmt.args) {
				args.add(arg.accept(this));
			}
			proc.match(args);
		} catch (TableError e) {
			throw new TypeCheckError(e.getMessage(), stmt);
		} catch (ValueError e) {
			throw new TypeCheckError(e.getMessage(), stmt);
		}
		return null;
	}

	@Override
	public TypeValue visit(Sequence stmt) {
		for (Stmt s : stmt.body) {
			s.accept(this);
		}
		return null;
	}

	@Override
	public TypeValue visit(IfThen stmt) {
		TypeValue test = stmt.test.accept(this);
		try {
			if (test.type() != Type.Bool) {
				throw new TypeCheckError("Test is not of type bool", stmt);
			}
		} catch (ValueError e) {
			throw new TypeCheckError(e.getMessage(), stmt);
		}
		stmt.trueClause.accept(this);
		return null;
	}

	@Override
	public TypeValue visit(IfThenElse stmt) {
		TypeValue test = stmt.test.accept(this);
		try {
			if (test.type() != Type.Bool) {
				throw new TypeCheckError("Test is not of type bool", stmt);
			}
		} catch (ValueError e) {
			throw new TypeCheckError(e.getMessage(), stmt);
		}
		stmt.trueClause.accept(this);
		stmt.falseClause.accept(this);
		return null;
	}

	@Override
	public TypeValue visit(While stmt) {
		TypeValue test = stmt.test.accept(this);
		try {
			if (test.type() != Type.Bool) {
				throw new TypeCheckError("Test is not of type bool", stmt);
			}
		} catch (ValueError e) {
			throw new TypeCheckError(e.getMessage(), stmt);
		}
		stmt.body.accept(this);
		return null;
	}

	@Override
	public TypeValue visit(Prompt stmt) {
		// nothing to check
		return null;
	}

	@Override
	public TypeValue visit(Prompt2 stmt) {
		try {
			TypeValue lhs = table.lookup(stmt.id);
			if (!(lhs.type() == Type.Int && lhs.isVar())) {
				throw new TypeCheckError("Prompt needs an integer variable", stmt);
			}
		} catch (TableError e) {
			throw new TypeCheckError(e.getMessage(), stmt);
		} catch (ValueError e) {
			throw new TypeCheckError(e.getMessage(), stmt);
		}
		return null;
	}

	@Override
	public TypeValue visit(Print stmt) {
		for (Item it : stmt.items) {
			it.accept(this);
		}
		return null;
	}

	@Override
	public TypeValue visit(ExprItem item) {
		try {
			TypeValue x = item.expr.accept(this);
			if (x.type() != Type.Int) {
				throw new TypeCheckError("Print needs an integer expression", item);
			}
		} catch (ValueError e) {
			throw new TypeCheckError(e.getMessage(), item);
		}
		return null;
	}

	@Override
	public TypeValue visit(StringItem item) {
		// nothing to check
		return null;
	}

	@Override
	public TypeValue visit(BinOp expr) {
		try {
			TypeValue lhs = expr.left.accept(this);
			TypeValue rhs = expr.right.accept(this);
			switch (expr.op) {
			case And:
			case Or:
				if (!(lhs.type() == Type.Bool && rhs.type() == Type.Bool)) {
					throw new TypeCheckError("Logical operator needs boolean operands", expr);
				}
				return new TypeValue.BoolVal();
			case EQ:
			case NE:
			case LE:
			case LT:
			case GE:
			case GT:
				if (!(lhs.type() == Type.Int && rhs.type() == Type.Int)) {
					throw new TypeCheckError("Relational operator needs integer operands", expr);
				}
				return new TypeValue.BoolVal();
			case Plus:
			case Minus:
			case Times:
			case Div:
			case Mod:
				if (!(lhs.type() == Type.Int && rhs.type() == Type.Int)) {
					throw new TypeCheckError("Arithmetic operator needs integer operands", expr);
				}
				return new TypeValue.IntVal();
			default:
				throw new TypeCheckError("Unknown operator", expr);
			}
		} catch (ValueError e) {
			throw new TypeCheckError(e.getMessage(), expr);
		}
	}

	@Override
	public TypeValue visit(UnOp expr) {
		try {
			TypeValue x = expr.expr.accept(this);
			switch (expr.op) {
			case Not:
				if (x.type() != Type.Bool) {
					throw new TypeCheckError("Logical not needs boolean operand", expr);
				}
				return new TypeValue.BoolVal();
			case Neg:
				if (x.type() != Type.Int) {
					throw new TypeCheckError("Negation needs integer operand", expr);
				}
				return new TypeValue.IntVal();
			default:
				throw new TypeCheckError("Unknown operator", expr);
			}
		} catch (ValueError e) {
			throw new TypeCheckError(e.getMessage(), expr);
		}
	}

	@Override
	public TypeValue visit(Num expr) {
		return new TypeValue.IntVal();
	}

	@Override
	public TypeValue visit(Id expr) {
		try {
			return table.lookup(expr.id);
		} catch (TableError e) {
			throw new TypeCheckError(e.getMessage(), expr);
		}
	}

	@Override
	public TypeValue visit(True expr) {
		return new TypeValue.BoolVal();
	}

	@Override
	public TypeValue visit(False expr) {
		return new TypeValue.BoolVal();
	}
}
