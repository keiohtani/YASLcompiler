package csc426.parser;

public interface Token {
	TokenType getType();
	
	String lexeme();
}
