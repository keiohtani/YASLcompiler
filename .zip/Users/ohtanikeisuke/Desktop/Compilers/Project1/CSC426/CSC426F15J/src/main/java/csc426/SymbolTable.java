package csc426;

import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

public class SymbolTable<T> {
	private Stack<Map<String, T>> scopes;

	public SymbolTable() {
		this.scopes = new Stack<>();
	}

	public void enter(String name) {
		scopes.push(new HashMap<>());
	}

	public void exit() {
		scopes.pop();
	}

	public void add(String id, T binding) throws TableError {
		Map<String, T> local = scopes.peek();
		if (local.containsKey(id)) {
			throw new TableError("Duplicate definition of " + id);
		}
		local.put(id, binding);
	}

	public T lookup(String id) throws TableError {
		for (int i = scopes.size() - 1; i >= 0; --i) {
			Map<String, T> scope = scopes.get(i);
			if (scope.containsKey(id)) {
				return scope.get(id);
			}
		}
		throw new TableError("Unknown identifier " + id);
	}

	public int level() {
		return scopes.size() - 1;
	}
}
