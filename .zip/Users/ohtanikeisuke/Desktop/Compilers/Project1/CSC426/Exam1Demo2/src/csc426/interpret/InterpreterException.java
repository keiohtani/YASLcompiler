package csc426.interpret;

@SuppressWarnings("serial")
public class InterpreterException extends RuntimeException {
	public InterpreterException(String message) {
		super(message);
	}
}
