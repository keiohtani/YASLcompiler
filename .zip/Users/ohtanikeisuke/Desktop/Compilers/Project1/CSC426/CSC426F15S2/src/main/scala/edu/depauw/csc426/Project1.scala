package edu.depauw.csc426

import YASLScanner.lexical

import scala.util.parsing.input.{PagedSeqReader, PagedSeq}

/**
 * @author bhoward
 */
object Project1 extends App {
  val in = new PagedSeqReader(PagedSeq.fromReader(Console.in))
  val scanner = new Scanner(in)
  
  var token = scanner.next
  while (token.tok != lexical.EOF) {
    println(token)
    token = scanner.next
  }
  
  println(token)
}