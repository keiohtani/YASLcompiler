package csc426.ast;

public enum Op2 {
	EQ, NE, LE, GE, LT, GT, Plus, Minus, Times, Div, Mod, And, Or
}