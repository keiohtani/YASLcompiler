/*
 * Scanner.h
 *
 *  Created on: Aug 30, 2015
 *      Author: bhoward
 */

#ifndef SCANNER_H_
#define SCANNER_H_

#include "Token.h"

#include <iosfwd>
#include <string>

class Scanner {
public:
	Scanner(std::istream& in);

	Token next();

private:
	std::istream& in;
	int line_num, column_num;
	std::string line;

	char current_char();
	void advance();
};

#endif /* SCANNER_H_ */
