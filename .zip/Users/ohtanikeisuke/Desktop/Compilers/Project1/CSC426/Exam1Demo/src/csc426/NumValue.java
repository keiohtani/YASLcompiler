package csc426;

import csc426.ast.Stmt;

public class NumValue implements Value {
	private double num;

	public NumValue(double num) {
		this.num = num;
	}

	public double asDouble() {
		return num;
	}

	public Stmt asStatement() throws Exception {
		throw new Exception("Attempt to use a number as a statement");
	}
}
