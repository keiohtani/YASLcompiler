package edu.depauw.csc426

/**
 * @author bhoward
 */
object Optimizer {
  def apply(program: List[Instruction]): List[Instruction] =
    pruneLabels(combineLabels(peephole(program)))

  def combineLabels(program: List[Instruction]): List[Instruction] = {
    def aux(program: List[Instruction], forward: Map[String, String]): Map[String, String] = program match {
      case Label(s1) :: Label(s2) :: tail => aux(Label(s2) :: tail, forward + (s1 -> s2))
      case Label(s1) :: Branch(s2) :: tail => aux(tail, forward + (s1 -> s2))
      case head :: tail => aux(tail, forward)
      case Nil => forward
    }
    
    val forward = aux(program, Map())
    
    def target(s: String): String = {
      if (forward contains s) target(forward(s)) else s
    }
    
    program map {
      case Branch(s) => Branch(target(s))
      case BranchZero(s) => BranchZero(target(s))
      case BranchNeg(s) => BranchNeg(target(s))
      case Call(s) => Call(target(s))
      case instruction => instruction
    }
  }
  
  def pruneLabels(program: List[Instruction]): List[Instruction] = {
    val labels = (program flatMap {
      case Branch(s) => Some(s)
      case BranchZero(s) => Some(s)
      case BranchNeg(s) => Some(s)
      case Call(s) => Some(s)
      case _ => None
    }).toSet
    
    program flatMap {
      case Label(s) => if (labels contains s) Some(Label(s)) else None
      case instruction => Some(instruction)
    }
  }

  def peephole(program: List[Instruction]): List[Instruction] = program match {
    // Remove unnecessary branches
    case Branch(s1) ::
      Label(s2) :: tail if s1 == s2 =>
      peephole(Label(s2) :: tail)

    // Remove useless operations
    case Reserve(0) :: tail => peephole(tail)

    case Drop(0) :: tail => peephole(tail)

    // Compress adjacent store/load  or load/store of same address
    case Address(n1, x1) ::
      Store ::
      Address(n2, x2) ::
      Load :: tail if n1 == n2 && x1 == x2 =>
      peephole(Dup :: Address(n1, x1) :: Store :: tail)

    case Address(n1, x1) ::
      Load ::
      Address(n2, x2) ::
      Store :: tail if n1 == n2 && x1 == x2 =>
      peephole(tail)

    // Constant folding
    case Constant(a) ::
      Constant(b) ::
      Add :: tail =>
      peephole(Constant(a + b) :: tail)

    case Constant(a) ::
      Constant(b) ::
      Sub :: tail =>
      peephole(Constant(a - b) :: tail)

    case Constant(a) ::
      Constant(b) ::
      Mul :: tail =>
      peephole(Constant(a * b) :: tail)

    case Constant(a) ::
      Constant(b) ::
      Div :: tail =>
      peephole(Constant(a / b) :: tail)

    case Constant(a) ::
      Constant(b) ::
      Mod :: tail =>
      peephole(Constant(a % b) :: tail)

    // Defaults
    case head :: tail => head :: peephole(tail)
    case Nil => Nil
  }
}

object PepOptimizer {
  implicit class Regex(sc: StringContext) {
    def r = new util.matching.Regex(sc.parts.mkString, sc.parts.tail.map(_ => "x"): _*)
  }

  def apply(program: List[String]): List[String] = program match {
    // Combine label: NOP followed by a non-label statement
    case r"(.*)$label: NOP0" ::
      r"(; .*)$comment" ::
      stmt :: tail if !(stmt contains ':') =>
      comment :: apply(f"${label + ": "}%-10s$stmt" :: tail)

    // Compact Constant/WriteChar into an immediate CHARO
    case r"LDA (\d+)$n, i" ::
      "SUBSP 2, i" ::
      "STA 0, s" ::
      "; WriteChar" ::
      "CHARO 1, s" ::
      "ADDSP 2, i" :: tail =>
      "; WriteChar" ::
        s"          CHARO $n, i" :: apply(tail)

    // Fix the indentation:
    case r"^([^;:]*)$stmt$$" :: tail =>
      s"          $stmt" :: apply(tail)

    // Defaults
    case head :: tail => head :: apply(tail)
    case Nil => Nil
  }
}