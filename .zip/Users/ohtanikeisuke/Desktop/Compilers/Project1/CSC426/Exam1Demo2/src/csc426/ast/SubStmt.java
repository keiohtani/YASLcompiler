package csc426.ast;

public class SubStmt implements Stmt {
	private String id;
	private Stmt body;
	
	public SubStmt(String id, Stmt body) {
		this.id = id;
		this.body = body;
	}

	public void accept(Visitor v) {
		v.sub(id, body);
	}
}
