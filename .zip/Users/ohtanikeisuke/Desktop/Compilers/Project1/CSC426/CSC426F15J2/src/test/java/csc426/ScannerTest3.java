package csc426;

import static org.junit.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.io.Reader;

import org.junit.Test;

public class ScannerTest3 {

	/**
	 * A test of identifiers.
	 * 
	 * test5.in is
-------
// Identifiers
aaaaaaaaaaaaaaaaaaaa aaaaaaaaaaaaaaaaaaab aaaaaaaaaaaaaaaaaxyz
a1234567890123456xyz
AaBbCcDdEeFfGgHhIi
JjKkLlMmNnOoPpQq
RrSsTtUuVvWwXx
YyZz0123456789
a A a1 A1
a+b-c*d=e;f.g//
 x  y   z
1a2b3c 4d5e6f 7G8H9I 0J-K=L
-------
	 * @throws IOException 
	 */
	@Test
	public void test5() throws IOException {
		Reader in = new BufferedReader(new FileReader("resource/project1/test5.in"));
		Scanner scanner = new Scanner(in);

		Token t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(2, 1), t.position);
		assertEquals("aaaaaaaaaaaaaaaaaaaa", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(2, 22), t.position);
		assertEquals("aaaaaaaaaaaaaaaaaaab", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(2, 43), t.position);
		assertEquals("aaaaaaaaaaaaaaaaaxyz", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(3, 1), t.position);
		assertEquals("a1234567890123456xyz", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(4, 1), t.position);
		assertEquals("AaBbCcDdEeFfGgHhIi", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(5, 1), t.position);
		assertEquals("JjKkLlMmNnOoPpQq", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(6, 1), t.position);
		assertEquals("RrSsTtUuVvWwXx", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(7, 1), t.position);
		assertEquals("YyZz0123456789", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(8, 1), t.position);
		assertEquals("a", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(8, 3), t.position);
		assertEquals("A", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(8, 5), t.position);
		assertEquals("a1", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(8, 8), t.position);
		assertEquals("A1", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(9, 1), t.position);
		assertEquals("a", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.PLUS, t.type);
		assertEquals(new Position(9, 2), t.position);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(9, 3), t.position);
		assertEquals("b", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.MINUS, t.type);
		assertEquals(new Position(9, 4), t.position);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(9, 5), t.position);
		assertEquals("c", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.STAR, t.type);
		assertEquals(new Position(9, 6), t.position);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(9, 7), t.position);
		assertEquals("d", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ASSIGN, t.type);
		assertEquals(new Position(9, 8), t.position);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(9, 9), t.position);
		assertEquals("e", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.SEMI, t.type);
		assertEquals(new Position(9, 10), t.position);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(9, 11), t.position);
		assertEquals("f", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.PERIOD, t.type);
		assertEquals(new Position(9, 12), t.position);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(9, 13), t.position);
		assertEquals("g", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(10, 2), t.position);
		assertEquals("x", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(10, 5), t.position);
		assertEquals("y", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(10, 9), t.position);
		assertEquals("z", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(11, 1), t.position);
		assertEquals("1", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(11, 2), t.position);
		assertEquals("a2b3c", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(11, 8), t.position);
		assertEquals("4", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(11, 9), t.position);
		assertEquals("d5e6f", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(11, 15), t.position);
		assertEquals("7", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(11, 16), t.position);
		assertEquals("G8H9I", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(11, 22), t.position);
		assertEquals("0", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(11, 23), t.position);
		assertEquals("J", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.MINUS, t.type);
		assertEquals(new Position(11, 24), t.position);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(11, 25), t.position);
		assertEquals("K", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ASSIGN, t.type);
		assertEquals(new Position(11, 26), t.position);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(11, 27), t.position);
		assertEquals("L", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.EOF, t.type);
		assertEquals(new Position(12, 1), t.position);
	}

	/**
	 * A test of whitespace.
	 * 
	 * test6.in is
-------
// Whitespace

 
  
a
 b
  c
	d	e
a{}b{ }c{	}d//e



     
//    }
{ // }
{{}{
// multiline brace comment
}
///{ just a single line

-------
	 * @throws IOException 
	 */
	@Test
	public void test6() throws IOException {
		Reader in = new BufferedReader(new FileReader("resource/project1/test6.in"));
		Scanner scanner = new Scanner(in);

		Token t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(5, 1), t.position);
		assertEquals("a", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(6, 2), t.position);
		assertEquals("b", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(7, 3), t.position);
		assertEquals("c", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(8, 2), t.position);
		assertEquals("d", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(8, 4), t.position);
		assertEquals("e", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(9, 1), t.position);
		assertEquals("a", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(9, 4), t.position);
		assertEquals("b", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(9, 8), t.position);
		assertEquals("c", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(9, 12), t.position);
		assertEquals("d", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.EOF, t.type);
		assertEquals(new Position(20, 1), t.position);
	}

	/**
	 * A test of keywords.
	 * 
	 * test7.in is
-------
// Keywords, Operators, and Punctuation
program const begin print end div mod and or not
var int bool proc if then else while do prompt true false
program+const-begin*print=end;div.mod:and(or)not,//
var==int<>bool<=proc>=if<then>else
program123 123program
1+2div 3mod 4mod5
beginend
div{}mod
const	print
div+-*=;.mod
mod.;=*-+div
<><=>=><<====
-------
	 * @throws IOException 
	 */
	@Test
	public void test7() throws IOException {
		Reader in = new BufferedReader(new FileReader("resource/project1/test7.in"));
		Scanner scanner = new Scanner(in);

		Token t = scanner.next();
		assertEquals(TokenType.PROGRAM, t.type);
		assertEquals(new Position(2, 1), t.position);

		t = scanner.next();
		assertEquals(TokenType.CONST, t.type);
		assertEquals(new Position(2, 9), t.position);

		t = scanner.next();
		assertEquals(TokenType.BEGIN, t.type);
		assertEquals(new Position(2, 15), t.position);

		t = scanner.next();
		assertEquals(TokenType.PRINT, t.type);
		assertEquals(new Position(2, 21), t.position);

		t = scanner.next();
		assertEquals(TokenType.END, t.type);
		assertEquals(new Position(2, 27), t.position);

		t = scanner.next();
		assertEquals(TokenType.DIV, t.type);
		assertEquals(new Position(2, 31), t.position);

		t = scanner.next();
		assertEquals(TokenType.MOD, t.type);
		assertEquals(new Position(2, 35), t.position);

		t = scanner.next();
		assertEquals(TokenType.AND, t.type);
		assertEquals(new Position(2, 39), t.position);

		t = scanner.next();
		assertEquals(TokenType.OR, t.type);
		assertEquals(new Position(2, 43), t.position);

		t = scanner.next();
		assertEquals(TokenType.NOT, t.type);
		assertEquals(new Position(2, 46), t.position);

		t = scanner.next();
		assertEquals(TokenType.VAR, t.type);
		assertEquals(new Position(3, 1), t.position);

		t = scanner.next();
		assertEquals(TokenType.INT, t.type);
		assertEquals(new Position(3, 5), t.position);

		t = scanner.next();
		assertEquals(TokenType.BOOL, t.type);
		assertEquals(new Position(3, 9), t.position);

		t = scanner.next();
		assertEquals(TokenType.PROC, t.type);
		assertEquals(new Position(3, 14), t.position);

		t = scanner.next();
		assertEquals(TokenType.IF, t.type);
		assertEquals(new Position(3, 19), t.position);

		t = scanner.next();
		assertEquals(TokenType.THEN, t.type);
		assertEquals(new Position(3, 22), t.position);

		t = scanner.next();
		assertEquals(TokenType.ELSE, t.type);
		assertEquals(new Position(3, 27), t.position);

		t = scanner.next();
		assertEquals(TokenType.WHILE, t.type);
		assertEquals(new Position(3, 32), t.position);

		t = scanner.next();
		assertEquals(TokenType.DO, t.type);
		assertEquals(new Position(3, 38), t.position);

		t = scanner.next();
		assertEquals(TokenType.PROMPT, t.type);
		assertEquals(new Position(3, 41), t.position);

		t = scanner.next();
		assertEquals(TokenType.TRUE, t.type);
		assertEquals(new Position(3, 48), t.position);

		t = scanner.next();
		assertEquals(TokenType.FALSE, t.type);
		assertEquals(new Position(3, 53), t.position);

		t = scanner.next();
		assertEquals(TokenType.PROGRAM, t.type);
		assertEquals(new Position(4, 1), t.position);

		t = scanner.next();
		assertEquals(TokenType.PLUS, t.type);
		assertEquals(new Position(4, 8), t.position);

		t = scanner.next();
		assertEquals(TokenType.CONST, t.type);
		assertEquals(new Position(4, 9), t.position);

		t = scanner.next();
		assertEquals(TokenType.MINUS, t.type);
		assertEquals(new Position(4, 14), t.position);

		t = scanner.next();
		assertEquals(TokenType.BEGIN, t.type);
		assertEquals(new Position(4, 15), t.position);

		t = scanner.next();
		assertEquals(TokenType.STAR, t.type);
		assertEquals(new Position(4, 20), t.position);

		t = scanner.next();
		assertEquals(TokenType.PRINT, t.type);
		assertEquals(new Position(4, 21), t.position);

		t = scanner.next();
		assertEquals(TokenType.ASSIGN, t.type);
		assertEquals(new Position(4, 26), t.position);

		t = scanner.next();
		assertEquals(TokenType.END, t.type);
		assertEquals(new Position(4, 27), t.position);

		t = scanner.next();
		assertEquals(TokenType.SEMI, t.type);
		assertEquals(new Position(4, 30), t.position);

		t = scanner.next();
		assertEquals(TokenType.DIV, t.type);
		assertEquals(new Position(4, 31), t.position);

		t = scanner.next();
		assertEquals(TokenType.PERIOD, t.type);
		assertEquals(new Position(4, 34), t.position);

		t = scanner.next();
		assertEquals(TokenType.MOD, t.type);
		assertEquals(new Position(4, 35), t.position);

		t = scanner.next();
		assertEquals(TokenType.COLON, t.type);
		assertEquals(new Position(4, 38), t.position);

		t = scanner.next();
		assertEquals(TokenType.AND, t.type);
		assertEquals(new Position(4, 39), t.position);

		t = scanner.next();
		assertEquals(TokenType.LPAREN, t.type);
		assertEquals(new Position(4, 42), t.position);

		t = scanner.next();
		assertEquals(TokenType.OR, t.type);
		assertEquals(new Position(4, 43), t.position);

		t = scanner.next();
		assertEquals(TokenType.RPAREN, t.type);
		assertEquals(new Position(4, 45), t.position);

		t = scanner.next();
		assertEquals(TokenType.NOT, t.type);
		assertEquals(new Position(4, 46), t.position);

		t = scanner.next();
		assertEquals(TokenType.COMMA, t.type);
		assertEquals(new Position(4, 49), t.position);

		t = scanner.next();
		assertEquals(TokenType.VAR, t.type);
		assertEquals(new Position(5, 1), t.position);

		t = scanner.next();
		assertEquals(TokenType.EQUAL, t.type);
		assertEquals(new Position(5, 4), t.position);

		t = scanner.next();
		assertEquals(TokenType.INT, t.type);
		assertEquals(new Position(5, 6), t.position);

		t = scanner.next();
		assertEquals(TokenType.NOTEQUAL, t.type);
		assertEquals(new Position(5, 9), t.position);

		t = scanner.next();
		assertEquals(TokenType.BOOL, t.type);
		assertEquals(new Position(5, 11), t.position);

		t = scanner.next();
		assertEquals(TokenType.LESSEQUAL, t.type);
		assertEquals(new Position(5, 15), t.position);

		t = scanner.next();
		assertEquals(TokenType.PROC, t.type);
		assertEquals(new Position(5, 17), t.position);

		t = scanner.next();
		assertEquals(TokenType.GREATEREQUAL, t.type);
		assertEquals(new Position(5, 21), t.position);

		t = scanner.next();
		assertEquals(TokenType.IF, t.type);
		assertEquals(new Position(5, 23), t.position);

		t = scanner.next();
		assertEquals(TokenType.LESS, t.type);
		assertEquals(new Position(5, 25), t.position);

		t = scanner.next();
		assertEquals(TokenType.THEN, t.type);
		assertEquals(new Position(5, 26), t.position);

		t = scanner.next();
		assertEquals(TokenType.GREATER, t.type);
		assertEquals(new Position(5, 30), t.position);

		t = scanner.next();
		assertEquals(TokenType.ELSE, t.type);
		assertEquals(new Position(5, 31), t.position);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(6, 1), t.position);
		assertEquals("program123", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(6, 12), t.position);
		assertEquals("123", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.PROGRAM, t.type);
		assertEquals(new Position(6, 15), t.position);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(7, 1), t.position);
		assertEquals("1", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.PLUS, t.type);
		assertEquals(new Position(7, 2), t.position);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(7, 3), t.position);
		assertEquals("2", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.DIV, t.type);
		assertEquals(new Position(7, 4), t.position);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(7, 8), t.position);
		assertEquals("3", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.MOD, t.type);
		assertEquals(new Position(7, 9), t.position);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(7, 13), t.position);
		assertEquals("4", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(7, 14), t.position);
		assertEquals("mod5", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.ID, t.type);
		assertEquals(new Position(8, 1), t.position);
		assertEquals("beginend", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.DIV, t.type);
		assertEquals(new Position(9, 1), t.position);

		t = scanner.next();
		assertEquals(TokenType.MOD, t.type);
		assertEquals(new Position(9, 6), t.position);

		t = scanner.next();
		assertEquals(TokenType.CONST, t.type);
		assertEquals(new Position(10, 1), t.position);

		t = scanner.next();
		assertEquals(TokenType.PRINT, t.type);
		assertEquals(new Position(10, 7), t.position);

		t = scanner.next();
		assertEquals(TokenType.DIV, t.type);
		assertEquals(new Position(11, 1), t.position);

		t = scanner.next();
		assertEquals(TokenType.PLUS, t.type);
		assertEquals(new Position(11, 4), t.position);

		t = scanner.next();
		assertEquals(TokenType.MINUS, t.type);
		assertEquals(new Position(11, 5), t.position);

		t = scanner.next();
		assertEquals(TokenType.STAR, t.type);
		assertEquals(new Position(11, 6), t.position);

		t = scanner.next();
		assertEquals(TokenType.ASSIGN, t.type);
		assertEquals(new Position(11, 7), t.position);

		t = scanner.next();
		assertEquals(TokenType.SEMI, t.type);
		assertEquals(new Position(11, 8), t.position);

		t = scanner.next();
		assertEquals(TokenType.PERIOD, t.type);
		assertEquals(new Position(11, 9), t.position);

		t = scanner.next();
		assertEquals(TokenType.MOD, t.type);
		assertEquals(new Position(11, 10), t.position);

		t = scanner.next();
		assertEquals(TokenType.MOD, t.type);
		assertEquals(new Position(12, 1), t.position);

		t = scanner.next();
		assertEquals(TokenType.PERIOD, t.type);
		assertEquals(new Position(12, 4), t.position);

		t = scanner.next();
		assertEquals(TokenType.SEMI, t.type);
		assertEquals(new Position(12, 5), t.position);

		t = scanner.next();
		assertEquals(TokenType.ASSIGN, t.type);
		assertEquals(new Position(12, 6), t.position);

		t = scanner.next();
		assertEquals(TokenType.STAR, t.type);
		assertEquals(new Position(12, 7), t.position);

		t = scanner.next();
		assertEquals(TokenType.MINUS, t.type);
		assertEquals(new Position(12, 8), t.position);

		t = scanner.next();
		assertEquals(TokenType.PLUS, t.type);
		assertEquals(new Position(12, 9), t.position);

		t = scanner.next();
		assertEquals(TokenType.DIV, t.type);
		assertEquals(new Position(12, 10), t.position);

		t = scanner.next();
		assertEquals(TokenType.NOTEQUAL, t.type);
		assertEquals(new Position(13, 1), t.position);

		t = scanner.next();
		assertEquals(TokenType.LESSEQUAL, t.type);
		assertEquals(new Position(13, 3), t.position);

		t = scanner.next();
		assertEquals(TokenType.GREATEREQUAL, t.type);
		assertEquals(new Position(13, 5), t.position);

		t = scanner.next();
		assertEquals(TokenType.GREATER, t.type);
		assertEquals(new Position(13, 7), t.position);

		t = scanner.next();
		assertEquals(TokenType.LESS, t.type);
		assertEquals(new Position(13, 8), t.position);

		t = scanner.next();
		assertEquals(TokenType.LESSEQUAL, t.type);
		assertEquals(new Position(13, 9), t.position);

		t = scanner.next();
		assertEquals(TokenType.EQUAL, t.type);
		assertEquals(new Position(13, 11), t.position);

		t = scanner.next();
		assertEquals(TokenType.ASSIGN, t.type);
		assertEquals(new Position(13, 13), t.position);

		t = scanner.next();
		assertEquals(TokenType.EOF, t.type);
		assertEquals(new Position(14, 1), t.position);
	}
	
	/**
	 * A test of numbers and strings.
	 * 
	 * test8.in is
-------
// Numbers and Strings
1 23 456 7890 1234567890
12345678901234567890// Too long?
 0123	456{}789
0000000000000
""
"this is a test"
"He said, ""Hello!"""
"a""b" "c" "d
e" "Unclosed string error
-------
	 * @throws IOException 
	 */
	@Test
	public void test8() throws IOException {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		PrintStream err = new PrintStream(out);
		System.setErr(err);
		
		Reader in = new BufferedReader(new FileReader("resource/project1/test8.in"));
		Scanner scanner = new Scanner(in);

		Token t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(2, 1), t.position);
		assertEquals("1", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(2, 3), t.position);
		assertEquals("23", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(2, 6), t.position);
		assertEquals("456", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(2, 10), t.position);
		assertEquals("7890", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(2, 15), t.position);
		assertEquals("1234567890", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(3, 1), t.position);
		assertEquals("12345678901234567890", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(4, 2), t.position);
		assertEquals("0", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(4, 3), t.position);
		assertEquals("123", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(4, 7), t.position);
		assertEquals("456", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(4, 12), t.position);
		assertEquals("789", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(5, 1), t.position);
		assertEquals("0", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(5, 2), t.position);
		assertEquals("0", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(5, 3), t.position);
		assertEquals("0", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(5, 4), t.position);
		assertEquals("0", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(5, 5), t.position);
		assertEquals("0", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(5, 6), t.position);
		assertEquals("0", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(5, 7), t.position);
		assertEquals("0", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(5, 8), t.position);
		assertEquals("0", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(5, 9), t.position);
		assertEquals("0", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(5, 10), t.position);
		assertEquals("0", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(5, 11), t.position);
		assertEquals("0", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(5, 12), t.position);
		assertEquals("0", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.NUM, t.type);
		assertEquals(new Position(5, 13), t.position);
		assertEquals("0", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.STRING, t.type);
		assertEquals(new Position(6, 1), t.position);
		assertEquals("", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.STRING, t.type);
		assertEquals(new Position(7, 1), t.position);
		assertEquals("this is a test", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.STRING, t.type);
		assertEquals(new Position(8, 1), t.position);
		assertEquals("He said, \"Hello!\"", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.STRING, t.type);
		assertEquals(new Position(9, 1), t.position);
		assertEquals("a\"b", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.STRING, t.type);
		assertEquals(new Position(9, 8), t.position);
		assertEquals("c", t.lexeme);

		t = scanner.next();
		assertEquals(TokenType.STRING, t.type);
		assertEquals(new Position(9, 12), t.position);
		assertEquals("d\ne", t.lexeme);

		String expected = "";
		assertEquals(expected, out.toString());
		out.reset();
		
		t = scanner.next();
		assertEquals(TokenType.EOF, t.type);
		assertEquals(new Position(11, 1), t.position);

		String expected2 = "Error: Unclosed string literal at 10:4\n";
		assertEquals(expected2, out.toString());
		out.reset();
	}
}
