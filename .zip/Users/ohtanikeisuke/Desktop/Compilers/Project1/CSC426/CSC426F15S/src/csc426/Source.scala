package csc426

import java.io.Reader
import java.io.IOException

/**
 * A Source object wraps a Reader (which will typically be a BufferedReader
 * wrapping another Reader connected to a file or an input stream) with the
 * ability to track the current line and column number, and to examine the
 * current character multiple times.
 *
 * @author bhoward
 */
class Source(in: Reader) {
  /*
   * Construct a Source wrapping the given Reader. Once constructed, the first
   * character of the source (at line 1, column 1) will be available via
   * current(), or else atEOF() will be true.
   */
  var line: Int = 0
  var column: Int = 0
  var current: Char = '\n'
  var atEOF: Boolean = false

  advance();

  /**
   * Advance to the next available character, if any. Either the new character
   * will be available through current(), or atEOF() will be true.
   */
  def advance(): Unit = {
    if (atEOF)
      return

    if (current == '\n') {
      line += 1
      column = 1
    } else {
      column += 1
    }

    try {
      val next = in.read();
      if (next == -1) {
        atEOF = true
      } else {
        current = next.toChar
      }
    } catch {
      case e: IOException =>
        Console.err.println("Error: " + e)
        sys.exit(1)
    }
  }

  /**
   * Close the underlying Reader.
   */
  def close(): Unit = {
    in.close()
  }
}
