package csc426.ast;

import java.util.Scanner;

import csc426.NumValue;
import csc426.SymbolTable;
import csc426.Value;

public class InputStmt implements Stmt {
	private String id;
	
	public InputStmt(String id) {
		this.id = id;
	}

	public String render(String indent) {
		return indent + "INPUT " + id + "\n";
	}

	public void interpret(SymbolTable<Value> table) {
		Scanner in = new Scanner(System.in);
		System.out.print("? ");
		double num = in.nextDouble();
		table.bind(id, new NumValue(num));
	}
}
