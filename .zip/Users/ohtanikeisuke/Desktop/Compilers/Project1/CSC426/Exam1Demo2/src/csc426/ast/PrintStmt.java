package csc426.ast;

public class PrintStmt implements Stmt {
	private String id;
	
	public PrintStmt(String id) {
		this.id = id;
	}

	public void accept(Visitor v) {
		v.print(id);
	}
}
